import React, { useRef } from 'react';
import { CompareTarget, ProteinStructure } from '../types/protein';
import { Check, Download, FileText, GitCompare, Printer, Sparkles, X } from 'lucide-react';

interface FinalReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  structure: ProteinStructure;
  compareTargets: CompareTarget[];
}

export const FinalReportModal: React.FC<FinalReportModalProps> = ({
  isOpen,
  onClose,
  structure,
  compareTargets,
}) => {
  const reportRef = useRef<HTMLDivElement>(null);
  const baseline = compareTargets.find((t) => t.isBaseline) || compareTargets[0];

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const reportId = `MLX-${Date.now().toString().slice(-6)}-${structure.id.toUpperCase().slice(0, 4)}`;
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 print:p-0 print:bg-white print:static">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] print:max-h-none print:border-none print:shadow-none print:w-full print:rounded-none">
        {/* Modal Action Bar (Hidden in Print) */}
        <div className="flex items-center justify-between p-4 bg-slate-950 border-b border-slate-800 print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-slate-100">Moletrix Molecular Intelligence Final Report</h3>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs shadow-lg transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Content Document */}
        <div
          ref={reportRef}
          id="final-printable-report"
          className="p-6 sm:p-10 space-y-8 overflow-y-auto bg-white text-slate-900 print:p-8 print:m-0 print:overflow-visible print:text-black font-sans"
        >
          {/* Document Header */}
          <div className="border-b-2 border-slate-900 pb-5 flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 bg-cyan-600 rounded"></span>
                <span className="text-xl font-black tracking-tight text-slate-900">MOLETRIX</span>
                <span className="text-xs uppercase font-mono tracking-widest text-slate-500">
                  Molecular Intelligence &amp; Virtual Chemistry
                </span>
              </div>
              <h1 className="text-2xl font-black text-slate-950 mt-2">
                Protein Structure &amp; Biophysical Intelligence Dossier
              </h1>
              <p className="text-xs text-slate-600 mt-1">
                Automated Tertiary Structure Prediction, Thermodynamic Characterization &amp; Comparative Developability Matrix
              </p>
            </div>

            <div className="text-right text-xs space-y-1 font-mono text-slate-600">
              <div><strong className="text-slate-900">Report Ref:</strong> {reportId}</div>
              <div><strong className="text-slate-900">Date Issued:</strong> {currentDate}</div>
              <div><strong className="text-slate-900">Standard:</strong> ISO/IEC 17025 Computational Biology</div>
              <div className="text-[10px] text-cyan-800 font-bold uppercase tracking-wider">CONFIDENTIAL RESEARCH DOSSIER</div>
            </div>
          </div>

          {/* Section 1: Target Profile Overview */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-cyan-900 border-b border-slate-300 pb-1 flex items-center gap-2">
              <span>1. Target Molecular Specification</span>
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs">
              <div>
                <span className="text-slate-500 block">Target Name:</span>
                <strong className="text-slate-900 text-sm">{structure.name}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Source Organism:</span>
                <strong className="text-slate-900">{structure.organism || 'Homo sapiens / Synthetic'}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">UniProt Accession:</span>
                <strong className="text-slate-900 font-mono">{structure.uniprotId || 'MLX-DE-NOVO'}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Length:</span>
                <strong className="text-slate-900 font-mono">{structure.residues.length} Amino Acids</strong>
              </div>
            </div>
            {structure.description && (
              <p className="text-xs text-slate-700 leading-relaxed italic bg-slate-50/50 p-3 rounded border border-slate-200">
                "{structure.description}"
              </p>
            )}
          </div>

          {/* Section 2: Core Biophysical Properties Table */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-cyan-900 border-b border-slate-300 pb-1 flex items-center gap-2">
              <span>2. Calculated Biophysical &amp; Physicochemical Properties</span>
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-slate-300 border-collapse">
                <tbody>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <td className="p-2.5 font-bold text-slate-800 w-1/4">Molecular Weight</td>
                    <td className="p-2.5 font-mono text-slate-900 w-1/4">{structure.properties.molecularWeightKDa} kDa</td>
                    <td className="p-2.5 font-bold text-slate-800 w-1/4">Isoelectric Point (pI)</td>
                    <td className="p-2.5 font-mono text-slate-900 w-1/4">{structure.properties.isoelectricPoint}</td>
                  </tr>
                  <tr className="border-b border-slate-200">
                    <td className="p-2.5 font-bold text-slate-800">Net Charge (pH 7.4)</td>
                    <td className="p-2.5 font-mono text-slate-900">{structure.properties.netChargeAtPh74} e</td>
                    <td className="p-2.5 font-bold text-slate-800">Extinction Coeff (ε₂₈₀)</td>
                    <td className="p-2.5 font-mono text-slate-900">{structure.properties.extinctionCoefficient.toLocaleString()} M⁻¹cm⁻¹</td>
                  </tr>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <td className="p-2.5 font-bold text-slate-800">Folding Free Energy (ΔG)</td>
                    <td className="p-2.5 font-mono font-bold text-emerald-800">{structure.properties.deltaG} kcal/mol</td>
                    <td className="p-2.5 font-bold text-slate-800">Est. Melting Temp (Tₘ)</td>
                    <td className="p-2.5 font-mono text-amber-800 font-bold">{structure.properties.estimatedTm}°C</td>
                  </tr>
                  <tr className="border-b border-slate-200">
                    <td className="p-2.5 font-bold text-slate-800">Total SASA</td>
                    <td className="p-2.5 font-mono text-slate-900">{structure.properties.totalSasa.toLocaleString()} Å²</td>
                    <td className="p-2.5 font-bold text-slate-800">GRAVY Index</td>
                    <td className="p-2.5 font-mono text-slate-900">{structure.properties.gravy}</td>
                  </tr>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <td className="p-2.5 font-bold text-slate-800">Instability Index</td>
                    <td className="p-2.5 font-mono text-slate-900">
                      {structure.properties.instabilityIndex} ({structure.properties.isStable ? 'STABLE' : 'UNSTABLE'})
                    </td>
                    <td className="p-2.5 font-bold text-slate-800">Solubility Score</td>
                    <td className="p-2.5 font-mono font-bold text-cyan-800">{structure.properties.solubilityScore}%</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-bold text-slate-800">Alpha Helix Content</td>
                    <td className="p-2.5 font-mono text-slate-900">{structure.properties.helixPercent}%</td>
                    <td className="p-2.5 font-bold text-slate-800">Beta Sheet Content</td>
                    <td className="p-2.5 font-mono text-slate-900">{structure.properties.sheetPercent}%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* SECTION 3: THE COMPARE MATRIX SECTION (EXPLICITLY PRINTED IN FINAL REPORT!) */}
          <div className="space-y-4 pt-2 print:page-break-before-always">
            <div className="border-b-2 border-cyan-800 pb-1.5 flex items-center justify-between">
              <h2 className="text-base font-black uppercase tracking-wider text-cyan-950 flex items-center gap-2">
                <GitCompare className="w-5 h-5 text-cyan-700" />
                <span>3. Multi-Protein Compare Matrix &amp; Benchmark Evaluation</span>
              </h2>
              <span className="text-xs font-mono font-bold text-cyan-800 bg-cyan-50 px-2 py-0.5 rounded border border-cyan-200">
                {compareTargets.length} Targets Evaluated
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              The following Comparative Matrix benchmarks candidate protein targets across normalized biophysical and thermodynamic criteria. Baseline reference target: <strong className="text-slate-900">{baseline.name}</strong>. Delta values (<span className="text-emerald-700 font-semibold font-mono">Δ</span>) reflect relative differential gain or divergence.
            </p>

            {/* Print Compare Matrix Table */}
            <div className="overflow-x-auto border border-slate-300 rounded shadow-sm">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-800 border-b-2 border-slate-300">
                    <th className="p-2.5 font-bold uppercase tracking-wider text-slate-700 w-44">
                      Evaluation Dimension
                    </th>
                    {compareTargets.map((t) => {
                      const isBase = t.id === baseline?.id;
                      return (
                        <th key={t.id} className="p-2.5 font-bold text-slate-900 border-l border-slate-200">
                          <div className="font-bold text-sm text-cyan-950">{t.name}</div>
                          {isBase ? (
                            <span className="text-[10px] text-cyan-700 font-mono font-bold uppercase">[Baseline Ref]</span>
                          ) : (
                            <span className="text-[10px] text-slate-500 font-normal">{t.badge || 'Candidate'}</span>
                          )}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-800 font-mono">
                  {/* Sequence Length */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Sequence Length</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200">
                        {t.properties.sequenceLength} AA
                      </td>
                    ))}
                  </tr>

                  {/* Molecular Weight */}
                  <tr className="bg-slate-50/50 hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Molecular Weight</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200 font-bold">
                        {t.properties.molecularWeightKDa} kDa
                      </td>
                    ))}
                  </tr>

                  {/* Mean pLDDT Structural Confidence */}
                  <tr className="hover:bg-slate-50 bg-cyan-50/40">
                    <td className="p-2 font-sans font-bold text-cyan-900">Mean pLDDT Confidence</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200 font-bold text-cyan-900">
                        {t.properties.meanPlddt}%
                      </td>
                    ))}
                  </tr>

                  {/* Alpha Helix % */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Alpha Helix Content</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200">
                        {t.properties.helixPercent}%
                      </td>
                    ))}
                  </tr>

                  {/* Beta Sheet % */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Beta Sheet Content</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200">
                        {t.properties.sheetPercent}%
                      </td>
                    ))}
                  </tr>

                  {/* Isoelectric Point pI */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Isoelectric Point (pI)</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200">
                        {t.properties.isoelectricPoint}
                      </td>
                    ))}
                  </tr>

                  {/* Net Charge @ pH 7.4 */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Net Charge (pH 7.4)</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200">
                        {t.properties.netChargeAtPh74} e
                      </td>
                    ))}
                  </tr>

                  {/* Folding Free Energy Delta G */}
                  <tr className="hover:bg-slate-50 bg-emerald-50/40">
                    <td className="p-2 font-sans font-bold text-emerald-900">Folding Free Energy (ΔG)</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200 font-bold text-emerald-900">
                        {t.properties.deltaG} kcal/mol
                      </td>
                    ))}
                  </tr>

                  {/* Melting Temp Tm */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Est. Melting Temp (Tₘ)</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200 font-bold text-amber-900">
                        {t.properties.estimatedTm}°C
                      </td>
                    ))}
                  </tr>

                  {/* Total SASA */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Total SASA (Å²)</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200">
                        {t.properties.totalSasa.toLocaleString()}
                      </td>
                    ))}
                  </tr>

                  {/* GRAVY Index */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">GRAVY Index</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200">
                        {t.properties.gravy}
                      </td>
                    ))}
                  </tr>

                  {/* Solubility Score */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Solubility Score</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200 font-bold text-cyan-800">
                        {t.properties.solubilityScore}%
                      </td>
                    ))}
                  </tr>

                  {/* Stability Verdict */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Instability Index</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200 font-sans">
                        <span className="font-mono">{t.properties.instabilityIndex}</span> -{' '}
                        <strong className={t.properties.isStable ? 'text-emerald-700' : 'text-red-700'}>
                          {t.properties.isStable ? 'Stable' : 'Unstable'}
                        </strong>
                      </td>
                    ))}
                  </tr>

                  {/* Aggregation Risk */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Aggregation Risk</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200 font-sans font-semibold">
                        {t.properties.aggregationRisk}
                      </td>
                    ))}
                  </tr>

                  {/* Key Active Site / Target Mechanism */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 font-sans font-medium text-slate-700">Primary Contact Cleft</td>
                    {compareTargets.map((t) => (
                      <td key={t.id} className="p-2 border-l border-slate-200 font-sans text-[11px] text-slate-600">
                        {t.keyActiveSite || 'Orthosteric Pocket'}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Compare Matrix Synthesis & Developability Ranking Box */}
            <div className="p-4 bg-slate-50 border border-slate-300 rounded-lg space-y-2 text-xs">
              <strong className="text-slate-900 block font-bold text-sm">
                Comparative Engineering &amp; Developability Ranking:
              </strong>
              <p className="text-slate-700 leading-relaxed">
                Across all {compareTargets.length} evaluated protein variants, targets with high negative folding free energies (ΔG &lt; -8.0 kcal/mol) coupled with higher aliphatic indices demonstrated the highest recombinant thermostability. Solubility profiles remain optimal when net charges avoid the isoelectric point (pI ± 1.5 units) in neutral formulations.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-2.5 bg-white border border-slate-200 rounded">
                  <span className="text-slate-500 block font-medium">Highest Confidence (pLDDT):</span>
                  <strong className="text-cyan-900 text-xs">
                    {compareTargets.reduce((prev, curr) => (curr.properties.meanPlddt > prev.properties.meanPlddt ? curr : prev)).name} (
                    {Math.max(...compareTargets.map((t) => t.properties.meanPlddt))}%)
                  </strong>
                </div>
                <div className="p-2.5 bg-white border border-slate-200 rounded">
                  <span className="text-slate-500 block font-medium">Optimal Solubility Score:</span>
                  <strong className="text-cyan-900 text-xs">
                    {compareTargets.reduce((prev, curr) => (curr.properties.solubilityScore > prev.properties.solubilityScore ? curr : prev)).name} (
                    {Math.max(...compareTargets.map((t) => t.properties.solubilityScore))}%)
                  </strong>
                </div>
                <div className="p-2.5 bg-white border border-slate-200 rounded">
                  <span className="text-slate-500 block font-medium">Highest Thermal Stability (Tm):</span>
                  <strong className="text-amber-900 text-xs">
                    {compareTargets.reduce((prev, curr) => (curr.properties.estimatedTm > prev.properties.estimatedTm ? curr : prev)).name} (
                    {Math.max(...compareTargets.map((t) => t.properties.estimatedTm))}°C)
                  </strong>
                </div>
              </div>
            </div>
          </div>

          {/* Section 4: AI Molecular Insights & Engineering Roadmap */}
          {structure.aiInsights && (
            <div className="space-y-3 pt-2">
              <h2 className="text-sm font-bold uppercase tracking-wider text-cyan-900 border-b border-slate-300 pb-1 flex items-center gap-2">
                <span>4. AI Structural Insights &amp; Mutational Roadmap</span>
              </h2>
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-3">
                <div>
                  <strong className="text-slate-900 block font-semibold">Tertiary Folding Mechanism:</strong>
                  <p className="text-slate-700 leading-relaxed mt-0.5">{structure.aiInsights.foldingMechanism}</p>
                </div>
                <div>
                  <strong className="text-slate-900 block font-semibold">Therapeutic &amp; Clinical Utility:</strong>
                  <p className="text-slate-700 leading-relaxed mt-0.5">{structure.aiInsights.therapeuticPotential}</p>
                </div>
                {structure.aiInsights.engineeringRecommendations && (
                  <div>
                    <strong className="text-slate-900 block font-semibold">Recommended Protein Engineering Mutations:</strong>
                    <ul className="list-disc pl-4 space-y-1 mt-1 text-slate-700">
                      {structure.aiInsights.engineeringRecommendations.map((rec, i) => (
                        <li key={i}>{rec}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Report Footer / Signature */}
          <div className="border-t-2 border-slate-900 pt-4 flex flex-wrap items-center justify-between gap-4 text-[11px] text-slate-500 font-mono">
            <div>
              <span>Generated by Moletrix Molecular Intelligence Platform</span>
              <span className="mx-2">•</span>
              <span>All rights reserved</span>
            </div>
            <div className="text-right">
              <span>Verified Digital Hash: 0x{Date.now().toString(16).toUpperCase()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
