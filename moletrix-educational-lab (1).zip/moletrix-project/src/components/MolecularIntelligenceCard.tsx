import React from 'react';
import { ProteinStructure } from '../types/protein';
import { Brain, CheckCircle, Cpu, Dna, Lightbulb, ShieldAlert, Sparkles, Target } from 'lucide-react';

interface MolecularIntelligenceCardProps {
  structure: ProteinStructure;
}

export const MolecularIntelligenceCard: React.FC<MolecularIntelligenceCardProps> = ({ structure }) => {
  const insights = structure.aiInsights;

  if (!insights) {
    return (
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
        <div className="flex items-center gap-2 pb-2">
          <Brain className="w-5 h-5 text-cyan-400" />
          <h3 className="text-base font-bold text-slate-100">Molecular Intelligence & AI Insights</h3>
        </div>
        <p className="text-xs text-slate-400">
          Predict structure to generate automated AI molecular folding mechanisms, therapeutic target assessments, and mutational recommendations.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl space-y-4">
      {/* Title */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-cyan-400" />
          <h3 className="text-base font-bold text-slate-100">AI Molecular Intelligence & Folding Insights</h3>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-cyan-950/60 border border-cyan-800/60 text-cyan-300 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Gemini 3.8 Flash Synthesis</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        {/* Folding Mechanism */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 font-bold text-slate-200">
            <Cpu className="w-4 h-4 text-purple-400" />
            <span>Tertiary Folding Mechanism</span>
          </div>
          <p className="text-slate-300 leading-relaxed">{insights.foldingMechanism}</p>
        </div>

        {/* Therapeutic Potential */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="flex items-center gap-2 font-bold text-slate-200">
            <Target className="w-4 h-4 text-emerald-400" />
            <span>Therapeutic &amp; Clinical Potential</span>
          </div>
          <p className="text-slate-300 leading-relaxed">{insights.therapeuticPotential}</p>
        </div>
      </div>

      {/* Functional Domains */}
      {insights.functionalDomains && insights.functionalDomains.length > 0 && (
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-slate-200">
            <Dna className="w-4 h-4 text-blue-400" />
            <span>Structural &amp; Functional Domains</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
            {insights.functionalDomains.map((dom, i) => (
              <div key={i} className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                <span className="font-semibold text-cyan-300 block">{i + 1}. Domain</span>
                <span className="text-[11px] text-slate-300">{dom}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Engineering Recommendations */}
      {insights.engineeringRecommendations && insights.engineeringRecommendations.length > 0 && (
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-slate-200">
            <Lightbulb className="w-4 h-4 text-amber-400" />
            <span>Protein Engineering &amp; Mutational Roadmap</span>
          </div>
          <ul className="space-y-1.5 pt-1">
            {insights.engineeringRecommendations.map((rec, i) => (
              <li key={i} className="flex items-start gap-2 text-slate-300 leading-relaxed">
                <CheckCircle className="w-3.5 h-3.5 text-amber-400 mt-0.5 shrink-0" />
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Confidence Assessment */}
      {insights.confidenceAssessment && (
        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
          <span>{insights.confidenceAssessment}</span>
          <span className="text-cyan-400 font-semibold shrink-0">Validated</span>
        </div>
      )}
    </div>
  );
};
