import React, { useState } from 'react';
import { PREDEFINED_PROTEINS } from '../data/sampleProteins';
import { sanitizeSequence } from '../utils/bioMath';
import { Dna, FileText, Sparkles, X } from 'lucide-react';

interface PredictModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPredefined: (id: string) => void;
  onPredictCustom: (name: string, sequence: string) => Promise<void>;
  isLoading: boolean;
}

export const PredictModal: React.FC<PredictModalProps> = ({
  isOpen,
  onClose,
  onSelectPredefined,
  onPredictCustom,
  isLoading,
}) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'custom'>('presets');
  const [customName, setCustomName] = useState('');
  const [customSequence, setCustomSequence] = useState('');
  const [seqError, setSeqError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCustomSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = sanitizeSequence(customSequence);
    if (clean.length < 10) {
      setSeqError('Sequence must contain at least 10 amino acid residues.');
      return;
    }
    setSeqError(null);
    await onPredictCustom(customName.trim() || 'Custom Predicted Protein', clean);
    onClose();
  };



  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-slate-100">Explore Protein Structures</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 text-xs font-medium">
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex-1 py-3 text-center transition cursor-pointer border-b-2 flex items-center justify-center gap-2 ${
              activeTab === 'presets'
                ? 'border-cyan-400 text-cyan-300 font-bold bg-slate-900/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Dna className="w-4 h-4" />
            <span>Target Library</span>
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`flex-1 py-3 text-center transition cursor-pointer border-b-2 flex items-center justify-center gap-2 ${
              activeTab === 'custom'
                ? 'border-cyan-400 text-cyan-300 font-bold bg-slate-900/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Custom Sequence / FASTA</span>
          </button>

        </div>

        {/* Tab Content */}
        <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* TAB 1: Benchmark Targets Library */}
          {activeTab === 'presets' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">
                Select a curated protein example to explore its educational structure and properties:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {PREDEFINED_PROTEINS.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      onSelectPredefined(p.id);
                      onClose();
                    }}
                    className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-cyan-500/80 hover:bg-slate-800/50 text-left transition cursor-pointer group space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-200 text-xs group-hover:text-cyan-300 transition">
                        {p.name}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-400 font-mono border border-cyan-800">
                        {p.sequence.length} AA
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 flex items-center justify-between">
                      <span>{p.organism}</span>
                      <span className="text-slate-500 font-mono">UniProt: {p.uniprotId}</span>
                    </div>
                    <div className="text-[10px] text-slate-500">Curated protein example</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: Custom Sequence Input */}
          {activeTab === 'custom' && (
            <form onSubmit={handleCustomSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Protein / Variant Name</label>
                <input
                  type="text"
                  placeholder="e.g., My Protein Sequence"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Amino Acid Sequence (Raw or FASTA format)
                  </label>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {sanitizeSequence(customSequence).length} AA
                  </span>
                </div>
                <textarea
                  rows={6}
                  placeholder=">Example_Protein&#10;MSKGEELFTGVVPILVELDGDVNGHKFSVSGEGEGDATYGKLTLKFICTTGKLPVPWPTLV..."
                  value={customSequence}
                  onChange={(e) => setCustomSequence(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500 uppercase"
                  required
                />
                {seqError && <p className="text-red-400 text-xs mt-1">{seqError}</p>}
                <p className="text-[11px] text-slate-500 mt-1">
                  Supports the 20 standard single-letter amino acid codes (A, C, D, E, F, G, H, I, K, L, M, N, P, Q, R, S, T, V, W, Y).
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg transition cursor-pointer flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{isLoading ? 'Building model...' : 'Build Educational 3D Model'}</span>
                </button>
              </div>
            </form>
          )}

        </div>
      </div>
    </div>
  );
};
