import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { ProteinStructure, Residue } from '../types/protein';
import { Camera, Eye, Info, Layers, Maximize2, Pause, Play, RotateCcw, ShieldCheck, Sparkles, Wand2 } from 'lucide-react';

interface StructureViewer3DProps {
  structure: ProteinStructure;
  selectedResidueIndex: number | null;
  onSelectResidue: (index: number | null) => void;
}

export type RenderMode = 'cartoon' | 'trace' | 'spheres' | 'sticks' | 'surface';
export type ColorMode = 'plddt' | 'secondary' | 'hydrophobicity' | 'charge' | 'spectrum';

export const StructureViewer3D: React.FC<StructureViewer3DProps> = ({
  structure,
  selectedResidueIndex,
  onSelectResidue,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const proteinGroupRef = useRef<THREE.Group | null>(null);
  const residueMeshesRef = useRef<Map<number, THREE.Object3D>>(new Map());

  // Viewer options
  const [renderMode, setRenderMode] = useState<RenderMode>('cartoon');
  const [colorMode, setColorMode] = useState<ColorMode>('plddt');
  const [showHbonds, setShowHbonds] = useState<boolean>(true);
  const [showDisulfides, setShowDisulfides] = useState<boolean>(true);
  const [showPockets, setShowPockets] = useState<boolean>(true);
  const [isRotating, setIsRotating] = useState<boolean>(true);
  const [isHudCollapsed, setIsHudCollapsed] = useState<boolean>(false);
  const [hoveredResidue, setHoveredResidue] = useState<Residue | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(null);

  // Helper to get residue color based on active colorMode
  const getResidueColor = (res: Residue): THREE.Color => {
    if (colorMode === 'plddt') {
      if (res.plddt >= 90) return new THREE.Color(0x1e3a8a); // Very high - Dark Blue
      if (res.plddt >= 70) return new THREE.Color(0x06b6d4); // Confident - Cyan
      if (res.plddt >= 50) return new THREE.Color(0xfacc15); // Low - Yellow
      return new THREE.Color(0xef4444); // Very low - Red / Orange
    }
    if (colorMode === 'secondary') {
      if (res.secondaryStructure === 'helix') return new THREE.Color(0x9333ea); // Violet / Purple
      if (res.secondaryStructure === 'sheet') return new THREE.Color(0x0d9488); // Teal
      return new THREE.Color(0x64748b); // Loop - Slate
    }
    if (colorMode === 'hydrophobicity') {
      // Kyte-Doolittle: -4.5 (polar/hydrophilic, blue) to +4.5 (hydrophobic, orange)
      const norm = (res.hydrophobicity + 4.5) / 9.0;
      const c = new THREE.Color();
      c.lerpColors(new THREE.Color(0x3b82f6), new THREE.Color(0xf97316), norm);
      return c;
    }
    if (colorMode === 'charge') {
      if (res.charge > 0) return new THREE.Color(0x2563eb); // Positive - Blue
      if (res.charge < 0) return new THREE.Color(0xdc2626); // Negative - Red
      return new THREE.Color(0x94a3b8); // Neutral - Slate
    }
    // Spectrum (N to C terminus rainbow)
    const ratio = (res.index - 1) / Math.max(1, structure.residues.length - 1);
    const col = new THREE.Color();
    col.setHSL((1.0 - ratio) * 0.7, 0.9, 0.55);
    return col;
  };

  // Re-build 3D mesh when structure, renderMode, or colorMode changes
  const buildProteinScene = () => {
    if (!proteinGroupRef.current || !structure) return;
    const group = proteinGroupRef.current;

    // Clear existing children
    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      if ((child as any).geometry) (child as any).geometry.dispose();
      if ((child as any).material) {
        if (Array.isArray((child as any).material)) {
          (child as any).material.forEach((m: any) => m.dispose());
        } else {
          (child as any).material.dispose();
        }
      }
    }
    residueMeshesRef.current.clear();

    const residues = structure.residues;
    if (residues.length === 0) return;

    const points = residues.map((r) => new THREE.Vector3(r.caCoord[0], r.caCoord[1], r.caCoord[2]));

    // 1. CARTOON RIBBON / TUBE
    if (renderMode === 'cartoon' || renderMode === 'trace') {
      if (points.length >= 2) {
        const curve = new THREE.CatmullRomCurve3(points, false, 'centripetal', 0.5);
        const tubularSegments = Math.max(64, residues.length * 10);
        const radius = renderMode === 'cartoon' ? 0.95 : 0.45;
        const radialSegments = renderMode === 'cartoon' ? 12 : 8;

        const tubeGeom = new THREE.TubeGeometry(curve, tubularSegments, radius, radialSegments, false);

        // Generate per-vertex colors based on residue positions
        const count = tubeGeom.attributes.position.count;
        const colors = new Float32Array(count * 3);
        const posAttr = tubeGeom.attributes.position;
        const tempVec = new THREE.Vector3();

        for (let i = 0; i < count; i++) {
          tempVec.fromBufferAttribute(posAttr, i);
          // Find closest residue
          let closestRes = residues[0];
          let minDist = Infinity;
          for (const r of residues) {
            const d = tempVec.distanceToSquared(new THREE.Vector3(r.caCoord[0], r.caCoord[1], r.caCoord[2]));
            if (d < minDist) {
              minDist = d;
              closestRes = r;
            }
          }
          const c = getResidueColor(closestRes);
          colors[i * 3] = c.r;
          colors[i * 3 + 1] = c.g;
          colors[i * 3 + 2] = c.b;
        }

        tubeGeom.setAttribute('color', new THREE.BufferAttribute(colors, 3));

        const tubeMat = new THREE.MeshStandardMaterial({
          vertexColors: true,
          roughness: 0.28,
          metalness: 0.15,
        });

        const tubeMesh = new THREE.Mesh(tubeGeom, tubeMat);
        tubeMesh.castShadow = true;
        tubeMesh.receiveShadow = true;
        group.add(tubeMesh);

        // Add distinct Alpha Helix cylinders and Beta Sheet directional arrows
        residues.forEach((res, idx) => {
          if (res.secondaryStructure === 'helix' && idx < residues.length - 1) {
            const p1 = new THREE.Vector3(...res.caCoord);
            const p2 = new THREE.Vector3(...residues[idx + 1].caCoord);
            const dist = p1.distanceTo(p2);
            if (dist > 0.1 && dist < 6) {
              const cylinderGeom = new THREE.CylinderGeometry(1.4, 1.4, dist, 8);
              cylinderGeom.translate(0, dist / 2, 0);
              cylinderGeom.rotateX(Math.PI / 2);

              const color = getResidueColor(res);
              const cylMat = new THREE.MeshStandardMaterial({
                color,
                roughness: 0.35,
                metalness: 0.2,
                transparent: true,
                opacity: 0.85,
              });
              const cylMesh = new THREE.Mesh(cylinderGeom, cylMat);
              cylMesh.position.copy(p1);
              cylMesh.lookAt(p2);
              group.add(cylMesh);
            }
          }
        });
      }
    }

    // 2. SPACE-FILLING SPHERES (van der Waals radius)
    if (renderMode === 'spheres') {
      const sphereGeom = new THREE.SphereGeometry(1.65, 16, 16);
      residues.forEach((res) => {
        const mat = new THREE.MeshStandardMaterial({
          color: getResidueColor(res),
          roughness: 0.3,
          metalness: 0.1,
        });
        const mesh = new THREE.Mesh(sphereGeom, mat);
        mesh.position.set(res.caCoord[0], res.caCoord[1], res.caCoord[2]);
        mesh.castShadow = true;
        (mesh as any).userData = { residue: res };
        group.add(mesh);
        residueMeshesRef.current.set(res.index, mesh);
      });
    }

    // 3. BALL & STICK / ATOMS
    if (renderMode === 'sticks' || renderMode === 'trace') {
      const nodeGeom = new THREE.SphereGeometry(renderMode === 'sticks' ? 0.9 : 0.6, 12, 12);
      residues.forEach((res) => {
        const mat = new THREE.MeshStandardMaterial({
          color: getResidueColor(res),
          roughness: 0.25,
          metalness: 0.2,
        });
        const mesh = new THREE.Mesh(nodeGeom, mat);
        mesh.position.set(res.caCoord[0], res.caCoord[1], res.caCoord[2]);
        (mesh as any).userData = { residue: res };
        group.add(mesh);
        residueMeshesRef.current.set(res.index, mesh);
      });

      // Sticks connecting C-alpha
      for (let i = 0; i < residues.length - 1; i++) {
        const p1 = new THREE.Vector3(...residues[i].caCoord);
        const p2 = new THREE.Vector3(...residues[i + 1].caCoord);
        const dist = p1.distanceTo(p2);
        const stickGeom = new THREE.CylinderGeometry(0.28, 0.28, dist, 8);
        stickGeom.translate(0, dist / 2, 0);
        stickGeom.rotateX(Math.PI / 2);
        const stickMat = new THREE.MeshStandardMaterial({
          color: 0x94a3b8,
          roughness: 0.4,
        });
        const stickMesh = new THREE.Mesh(stickGeom, stickMat);
        stickMesh.position.copy(p1);
        stickMesh.lookAt(p2);
        group.add(stickMesh);
      }
    }

    // 4. SURFACE ENVELOPE (Solvent Accessible Surface Mesh)
    if (renderMode === 'surface') {
      if (points.length >= 4) {
        // Build surface convex/envelope cloud
        const hullGeom = new THREE.DodecahedronGeometry(1.8, 1);
        residues.forEach((res) => {
          const mat = new THREE.MeshStandardMaterial({
            color: getResidueColor(res),
            roughness: 0.5,
            metalness: 0.1,
            transparent: true,
            opacity: 0.65,
          });
          const mesh = new THREE.Mesh(hullGeom, mat);
          mesh.position.set(res.caCoord[0], res.caCoord[1], res.caCoord[2]);
          mesh.scale.set(1.9, 1.9, 1.9);
          group.add(mesh);
        });
      }
    }

    // 5. DISULFIDE BRIDGES (Golden Covalent Rods)
    if (showDisulfides && structure.disulfideBonds) {
      structure.disulfideBonds.forEach((ssb) => {
        const r1 = residues.find((r) => r.index === ssb.residue1);
        const r2 = residues.find((r) => r.index === ssb.residue2);
        if (r1 && r2) {
          const p1 = new THREE.Vector3(...r1.caCoord);
          const p2 = new THREE.Vector3(...r2.caCoord);
          const dist = p1.distanceTo(p2);

          const bondGeom = new THREE.CylinderGeometry(0.45, 0.45, dist, 8);
          bondGeom.translate(0, dist / 2, 0);
          bondGeom.rotateX(Math.PI / 2);
          const bondMat = new THREE.MeshStandardMaterial({
            color: 0xf59e0b, // Bright Gold
            emissive: 0xd97706,
            emissiveIntensity: 0.5,
            metalness: 0.8,
            roughness: 0.2,
          });
          const bondMesh = new THREE.Mesh(bondGeom, bondMat);
          bondMesh.position.copy(p1);
          bondMesh.lookAt(p2);
          group.add(bondMesh);

          // Sulfur marker spheres
          const sGeom = new THREE.SphereGeometry(0.75, 12, 12);
          const sMat = new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.6 });
          const s1 = new THREE.Mesh(sGeom, sMat);
          s1.position.copy(p1);
          const s2 = new THREE.Mesh(sGeom, sMat);
          s2.position.copy(p2);
          group.add(s1);
          group.add(s2);
        }
      });
    }

    // 6. HYDROGEN BONDS (Dashed Glowing Lines)
    if (showHbonds && structure.hydrogenBonds) {
      structure.hydrogenBonds.slice(0, 45).forEach((hb) => {
        const r1 = residues.find((r) => r.index === hb.fromResidue);
        const r2 = residues.find((r) => r.index === hb.toResidue);
        if (r1 && r2) {
          const p1 = new THREE.Vector3(...r1.caCoord);
          const p2 = new THREE.Vector3(...r2.caCoord);
          const lineGeom = new THREE.BufferGeometry().setFromPoints([p1, p2]);
          const lineMat = new THREE.LineDashedMaterial({
            color: 0xfde047, // Yellow
            dashSize: 0.5,
            gapSize: 0.35,
            linewidth: 2,
          });
          const line = new THREE.Line(lineGeom, lineMat);
          line.computeLineDistances();
          group.add(line);
        }
      });
    }

    // 7. ACTIVE POCKETS HIGHLIGHT
    if (showPockets && structure.pockets) {
      const pocketResSet = new Set<number>();
      structure.pockets.forEach((p) => p.residues.forEach((r) => pocketResSet.add(r)));

      pocketResSet.forEach((resIdx) => {
        const res = residues.find((r) => r.index === resIdx);
        if (res) {
          const glowGeom = new THREE.SphereGeometry(1.8, 12, 12);
          const glowMat = new THREE.MeshStandardMaterial({
            color: 0x10b981, // Emerald Green
            emissive: 0x059669,
            emissiveIntensity: 0.6,
            transparent: true,
            opacity: 0.65,
            wireframe: true,
          });
          const glowMesh = new THREE.Mesh(glowGeom, glowMat);
          glowMesh.position.set(res.caCoord[0], res.caCoord[1], res.caCoord[2]);
          group.add(glowMesh);
        }
      });
    }

    // 8. SELECTED RESIDUE MARKER
    if (selectedResidueIndex !== null) {
      const selRes = residues.find((r) => r.index === selectedResidueIndex);
      if (selRes) {
        const ringGeom = new THREE.RingGeometry(2.0, 2.5, 24);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0xffffff,
          side: THREE.DoubleSide,
        });
        const ringMesh = new THREE.Mesh(ringGeom, ringMat);
        ringMesh.position.set(selRes.caCoord[0], selRes.caCoord[1], selRes.caCoord[2]);
        ringMesh.lookAt(cameraRef.current?.position || new THREE.Vector3(0, 0, 40));
        group.add(ringMesh);
      }
    }
  };

  // Main Three.js Scene Setup (Mount once)
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Detect software WebGL guard
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x090d16); // Deep slate molecular laboratory tone

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 15, 60);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: true,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.replaceChildren(renderer.domElement);

    // Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 250;
    controls.minDistance = 10;
    controlsRef.current = controls;

    // Studio Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.45);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x1e293b, 0.5);
    hemiLight.position.set(0, 50, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(30, 45, 40);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.bias = -0.0005;
    }
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 0.7);
    fillLight.position.set(-30, -15, -30);
    scene.add(fillLight);

    // Molecular Protein Group
    const proteinGroup = new THREE.Group();
    scene.add(proteinGroup);
    proteinGroupRef.current = proteinGroup;

    // Raycaster for hover/selection
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerMove = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(proteinGroup.children, true);

      let foundRes: Residue | null = null;
      for (const hit of intersects) {
        if ((hit.object as any).userData?.residue) {
          foundRes = (hit.object as any).userData.residue;
          break;
        }
      }

      if (foundRes) {
        setHoveredResidue(foundRes);
        setTooltipPos({ x: e.clientX, y: e.clientY });
      } else {
        setHoveredResidue(null);
      }
    };

    const handleClick = () => {
      if (hoveredResidue) {
        onSelectResidue(hoveredResidue.index);
      }
    };

    renderer.domElement.addEventListener('pointermove', handlePointerMove);
    renderer.domElement.addEventListener('click', handleClick);

    // Animation Render Loop
    let animId = 0;
    const animate = () => {
      animId = requestAnimationFrame(animate);

      if (isRotating && proteinGroupRef.current) {
        proteinGroupRef.current.rotation.y += 0.0035;
      }

      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize Handler
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('pointermove', handlePointerMove);
      renderer.domElement.removeEventListener('click', handleClick);
      renderer.dispose();
    };
  }, []);

  // Update 3D scene on prop changes
  useEffect(() => {
    buildProteinScene();
  }, [structure, renderMode, colorMode, showHbonds, showDisulfides, showPockets, selectedResidueIndex]);

  // Camera Presets
  const setCameraPreset = (preset: 'front' | 'top' | 'side' | 'isometric' | 'pocket') => {
    if (!cameraRef.current || !controlsRef.current) return;
    const camera = cameraRef.current;
    const controls = controlsRef.current;

    if (preset === 'front') {
      camera.position.set(0, 0, 55);
    } else if (preset === 'top') {
      camera.position.set(0, 55, 0);
    } else if (preset === 'side') {
      camera.position.set(55, 0, 0);
    } else if (preset === 'isometric') {
      camera.position.set(35, 30, 35);
    } else if (preset === 'pocket' && structure.pockets?.[0]?.residues.length) {
      const pIdx = structure.pockets[0].residues[0];
      const res = structure.residues.find((r) => r.index === pIdx);
      if (res) {
        camera.position.set(res.caCoord[0] + 12, res.caCoord[1] + 10, res.caCoord[2] + 18);
        controls.target.set(...res.caCoord);
      }
    }
    controls.update();
  };

  // Export Screenshot
  const handleTakeSnapshot = () => {
    if (!rendererRef.current) return;
    const dataUrl = rendererRef.current.domElement.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `${structure.id || 'protein'}_moletrix_3d.png`;
    a.click();
  };

  // Export PDB
  const handleDownloadPdb = () => {
    if (!structure.pdbString) return;
    const blob = new Blob([structure.pdbString], { type: 'chemical/x-pdb' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${structure.id || 'protein'}.pdb`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="relative w-full h-[580px] bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col">
      {/* Top Header Overlay */}
      <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2 pointer-events-auto">
        <div className="bg-slate-900/85 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-slate-700/80 shadow-lg flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
          <span className="text-xs font-semibold text-slate-100 uppercase tracking-wider">{structure.name}</span>
          <span className="text-[11px] text-slate-400">| {structure.residues.length} residues</span>
        </div>

        <div className="bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/80 shadow-lg flex items-center gap-2">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-xs text-slate-300">Mean pLDDT:</span>
          <span className="text-xs font-bold text-cyan-300">{structure.properties.meanPlddt}%</span>
        </div>

        {structure.uniprotId && (
          <span className="bg-slate-900/85 text-[11px] font-mono text-cyan-400 border border-cyan-800/60 px-2.5 py-1 rounded-xl shadow-lg">
            UniProt: {structure.uniprotId}
          </span>
        )}
      </div>

      {/* Top-Right Action Controls */}
      <div className="absolute top-4 right-4 z-10 flex items-center gap-2 pointer-events-auto">
        <button
          onClick={handleTakeSnapshot}
          title="Export High-Res Snapshot"
          className="bg-slate-900/85 hover:bg-slate-800 text-slate-200 p-2 rounded-xl border border-slate-700 transition shadow-lg flex items-center gap-1.5 text-xs font-medium cursor-pointer"
        >
          <Camera className="w-4 h-4 text-cyan-400" />
          <span className="hidden sm:inline">Snapshot</span>
        </button>

        <button
          onClick={handleDownloadPdb}
          title="Download Coordinate File (.PDB)"
          className="bg-cyan-600/90 hover:bg-cyan-500 text-white px-3 py-2 rounded-xl border border-cyan-400/30 transition shadow-lg flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-cyan-200" />
          <span>Export PDB</span>
        </button>
      </div>

      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Hover Residue Floating Tooltip */}
      {hoveredResidue && tooltipPos && (
        <div
          style={{
            left: Math.min(window.innerWidth - 220, tooltipPos.x + 12),
            top: Math.max(10, tooltipPos.y - 70),
          }}
          className="fixed z-50 pointer-events-none bg-slate-900/95 text-slate-100 border border-cyan-500/50 rounded-xl px-3 py-2 shadow-2xl text-xs space-y-0.5"
        >
          <div className="font-bold text-cyan-300 flex items-center gap-1.5">
            <span>#{hoveredResidue.index} {hoveredResidue.name} ({hoveredResidue.code1})</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 uppercase font-mono">{hoveredResidue.secondaryStructure}</span>
          </div>
          <div className="text-[11px] text-slate-300 flex items-center justify-between gap-4">
            <span>pLDDT Confidence:</span>
            <span className="font-semibold text-blue-300">{hoveredResidue.plddt}%</span>
          </div>
          <div className="text-[11px] text-slate-300 flex items-center justify-between gap-4">
            <span>Ramachandran (φ, ψ):</span>
            <span className="font-mono text-slate-400">{hoveredResidue.phi}°, {hoveredResidue.psi}°</span>
          </div>
          {hoveredResidue.isBindingSite && (
            <div className="text-[10px] font-semibold text-emerald-400 flex items-center gap-1 pt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span>Active Binding Site Residue</span>
            </div>
          )}
        </div>
      )}

      {/* Color Legend (Top Left under badge) */}
      <div className="absolute left-4 top-16 z-10 pointer-events-auto bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-xl p-2.5 shadow-xl text-[11px] hidden sm:block">
        <div className="text-slate-400 font-medium pb-1.5 border-b border-slate-800/80">
          {colorMode === 'plddt' && 'AlphaFold pLDDT Legend'}
          {colorMode === 'secondary' && 'Secondary Structure'}
          {colorMode === 'hydrophobicity' && 'Kyte-Doolittle Hydropathy'}
          {colorMode === 'charge' && 'Residue Charge (pH 7.4)'}
          {colorMode === 'spectrum' && 'N → C Chain Direction'}
        </div>
        <div className="pt-1.5 space-y-1">
          {colorMode === 'plddt' && (
            <>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-blue-900 border border-blue-700"></span><span className="text-slate-300">Very High (&gt;90)</span></div>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-cyan-500"></span><span className="text-slate-300">Confident (70-90)</span></div>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-yellow-400"></span><span className="text-slate-300">Low (50-70)</span></div>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-red-500"></span><span className="text-slate-300">Very Low (&lt;50)</span></div>
            </>
          )}
          {colorMode === 'secondary' && (
            <>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-purple-600"></span><span className="text-slate-300">Alpha Helix ({structure.properties.helixPercent}%)</span></div>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-teal-600"></span><span className="text-slate-300">Beta Sheet ({structure.properties.sheetPercent}%)</span></div>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-slate-500"></span><span className="text-slate-300">Loop / Turn ({structure.properties.loopPercent}%)</span></div>
            </>
          )}
          {colorMode === 'hydrophobicity' && (
            <>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-orange-500"></span><span className="text-slate-300">Hydrophobic (Buried)</span></div>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-blue-500"></span><span className="text-slate-300">Hydrophilic (Surface)</span></div>
            </>
          )}
          {colorMode === 'charge' && (
            <>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-blue-600"></span><span className="text-slate-300">Basic / Positive (+1)</span></div>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-red-600"></span><span className="text-slate-300">Acidic / Negative (-1)</span></div>
              <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm bg-slate-400"></span><span className="text-slate-300">Neutral (0)</span></div>
            </>
          )}
          {colorMode === 'spectrum' && (
            <div className="flex items-center gap-1.5 pt-0.5">
              <span className="text-[10px] text-blue-400 font-mono">N</span>
              <div className="w-20 h-2 rounded bg-gradient-to-r from-blue-500 via-green-400 via-yellow-400 to-red-500"></div>
              <span className="text-[10px] text-red-400 font-mono">C</span>
            </div>
          )}
        </div>
      </div>

      {/* Ergonomic Collapsible Bottom Dock (Zero Viewport Occlusion) */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-[94%] max-w-4xl pointer-events-auto">
        {/* Toggle Collapse Pill */}
        <div className="flex justify-center -mb-2">
          <button
            onClick={() => setIsHudCollapsed(!isHudCollapsed)}
            className="bg-slate-900/90 hover:bg-slate-800 text-slate-300 text-[11px] font-medium px-3.5 py-1 rounded-t-xl border-t border-x border-slate-700/80 shadow-md cursor-pointer transition flex items-center gap-1.5"
          >
            <span>{isHudCollapsed ? '▲ Show Molecular Controls' : '▼ Cinema / Clean View'}</span>
          </button>
        </div>

        {/* Control Toolbar */}
        {!isHudCollapsed && (
          <div className="bg-slate-900/92 backdrop-blur-md rounded-2xl border border-slate-700/80 p-3 shadow-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
            {/* Render Style Mode */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mr-1">Style:</span>
              <div className="bg-slate-950/80 p-1 rounded-xl border border-slate-800 flex items-center gap-1">
                {(['cartoon', 'trace', 'spheres', 'sticks', 'surface'] as RenderMode[]).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => setRenderMode(mode)}
                    className={`px-2.5 py-1 rounded-lg capitalize font-medium transition cursor-pointer ${
                      renderMode === mode
                        ? 'bg-cyan-600 text-white shadow-sm font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>

            {/* Color Scheme */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mr-1">Color:</span>
              <div className="bg-slate-950/80 p-1 rounded-xl border border-slate-800 flex items-center gap-1">
                {(
                  [
                    { key: 'plddt', label: 'pLDDT' },
                    { key: 'secondary', label: '2° Struct' },
                    { key: 'hydrophobicity', label: 'Hydropathy' },
                    { key: 'charge', label: 'Charge' },
                    { key: 'spectrum', label: 'Spectrum' },
                  ] as { key: ColorMode; label: string }[]
                ).map(({ key, label }) => (
                  <button
                    key={key}
                    onClick={() => setColorMode(key)}
                    className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
                      colorMode === key
                        ? 'bg-blue-600 text-white shadow-sm font-semibold'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles (Disulfides, H-Bonds, Pockets, Spin) */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowDisulfides(!showDisulfides)}
                className={`px-2.5 py-1 rounded-xl border transition cursor-pointer font-medium ${
                  showDisulfides
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-semibold'
                    : 'bg-slate-800/60 text-slate-400 border-slate-700/60'
                }`}
                title="Toggle Cys-Cys Disulfide Bridges"
              >
                S-S Bridges
              </button>

              <button
                onClick={() => setShowHbonds(!showHbonds)}
                className={`px-2.5 py-1 rounded-xl border transition cursor-pointer font-medium ${
                  showHbonds
                    ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50 font-semibold'
                    : 'bg-slate-800/60 text-slate-400 border-slate-700/60'
                }`}
                title="Toggle Hydrogen Bond Network"
              >
                H-Bonds
              </button>

              <button
                onClick={() => setShowPockets(!showPockets)}
                className={`px-2.5 py-1 rounded-xl border transition cursor-pointer font-medium ${
                  showPockets
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-semibold'
                    : 'bg-slate-800/60 text-slate-400 border-slate-700/60'
                }`}
                title="Toggle Active Binding Pocket Highlight"
              >
                Pockets
              </button>

              <button
                onClick={() => setIsRotating(!isRotating)}
                className={`p-1.5 rounded-xl border transition cursor-pointer ${
                  isRotating
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                    : 'bg-slate-800/60 text-slate-400 border-slate-700/60'
                }`}
                title={isRotating ? 'Pause Rotation' : 'Auto Rotate'}
              >
                {isRotating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              </button>

              <button
                onClick={() => setCameraPreset('isometric')}
                className="p-1.5 rounded-xl border border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
                title="Reset Camera View"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
