import React, { useState } from 'react';
import { SmallMolecule } from '../data/sampleMolecules';
import { AlertTriangle, FlaskConical, ShieldCheck } from 'lucide-react';

interface MoleculeDetailsProps {
  molecule: SmallMolecule;
}

type DetailTab = 'properties' | 'spectroscopy' | 'safety';

/** Educational chemistry facts only. Drug-development and synthesis workflows are not exposed. */
export const MoleculeDetails: React.FC<MoleculeDetailsProps> = ({ molecule }) => {
  const [activeTab, setActiveTab] = useState<DetailTab>('properties');
  const p = molecule.properties;
  const lip = molecule.lipinskiRuleOf5;
  const tabs: { id: DetailTab; label: string }[] = [
    { id: 'properties', label: 'Properties' },
    { id: 'spectroscopy', label: 'Spectroscopy' },
    { id: 'safety', label: 'Safety & GHS' },
  ];

  return (
    <section className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl space-y-4" aria-label={`${molecule.name} chemical details`}>
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <FlaskConical className="w-5 h-5 text-cyan-400" aria-hidden="true" />
          <h3 className="text-base font-bold text-slate-100">{molecule.name} — Chemical Details</h3>
        </div>
        <div className="flex flex-wrap items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs" role="tablist" aria-label="Chemical detail sections">
          {tabs.map((tab) => (
            <button key={tab.id} type="button" role="tab" aria-selected={activeTab === tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${activeTab === tab.id ? 'bg-cyan-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {activeTab === 'properties' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Metric label="Molecular weight" value={`${p.molecularWeight} g/mol`} />
            <Metric label="LogP" value={String(p.logP)} accent />
            <Metric label="Polar surface area" value={`${p.tpsa} Å²`} />
            <Metric label="H-bond donors / acceptors" value={`${p.hBondDonors} / ${p.hBondAcceptors}`} />
          </div>
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-cyan-400" /><span className="font-bold text-slate-200 text-xs">Lipinski property reference</span></div>
              <span className="text-[10px] px-2 py-0.5 rounded font-bold uppercase bg-slate-900 text-slate-300 border border-slate-700">{lip.passed ? 'Within reference' : `${lip.violations} outside reference`}</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{lip.details}</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px]">
              <Reference label={`MW < 500 Da (${p.molecularWeight})`} pass={lip.mwPass} />
              <Reference label={`LogP < 5 (${p.logP})`} pass={lip.logPPass} />
              <Reference label={`H-donors ≤ 5 (${p.hBondDonors})`} pass={lip.donorsPass} />
              <Reference label={`H-acceptors ≤ 10 (${p.hBondAcceptors})`} pass={lip.acceptorsPass} />
            </div>
            <p className="text-[10px] text-slate-500">This is a physicochemical teaching reference, not a prediction of safety, effectiveness, or suitability for use.</p>
          </div>
        </div>
      )}

      {activeTab === 'spectroscopy' && (
        <div className="space-y-3 text-xs">
          {molecule.spectroscopy ? <>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800"><span className="font-bold text-cyan-300 block mb-1">UV-Vis maximum absorbance</span><span className="text-slate-200 font-mono text-sm">{molecule.spectroscopy.uvVisMax}</span></div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="font-bold text-slate-200 block">Infrared vibrational peaks</span>
              <div className="overflow-x-auto"><table className="w-full text-left font-mono text-[11px]"><thead><tr className="border-b border-slate-800 text-slate-400"><th className="py-1">Wavenumber</th><th className="py-1">Intensity</th><th className="py-1">Bond</th><th className="py-1">Assignment</th></tr></thead><tbody className="divide-y divide-slate-800/40 text-slate-300">{molecule.spectroscopy.irPeaks?.map((peak, i) => <tr key={i}><td className="py-1 font-bold text-cyan-300">{peak.wavenumber} cm⁻¹</td><td className="py-1">{peak.intensity}</td><td className="py-1 font-sans">{peak.bond}</td><td className="py-1 font-sans">{peak.assignment}</td></tr>)}</tbody></table></div>
            </div>
          </> : <p className="text-slate-400 text-center py-6">No spectroscopy data is included for this library entry.</p>}
        </div>
      )}

      {activeTab === 'safety' && (
        <div className="space-y-3 text-xs">
          {molecule.safetyAndHazards ? <>
            <div className="flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-amber-400" /><span className="font-bold text-slate-200">GHS signal word: <strong className="text-amber-400 uppercase">{molecule.safetyAndHazards.ghsSignalWord || 'WARNING'}</strong></span></div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1"><span className="font-bold text-amber-300 block">Hazard statements</span><ul className="list-disc pl-4 space-y-0.5 text-slate-300">{molecule.safetyAndHazards.hazardStatements?.map((h, i) => <li key={i}>{h}</li>)}</ul></div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1"><span className="font-bold text-emerald-300 block">General protective equipment listed in the source data</span><div className="flex flex-wrap gap-1.5 pt-1">{molecule.safetyAndHazards.ppeChecklist?.map((item, i) => <span key={i} className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-slate-200">{item}</span>)}</div></div>
          </> : <p className="text-slate-400 text-center py-6">No hazard data is included. Always consult the official safety data sheet and a qualified supervisor before laboratory work.</p>}
        </div>
      )}
    </section>
  );
};

const Metric = ({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) => (
  <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800"><span className="text-[11px] text-slate-400 block">{label}</span><strong className={`text-lg ${accent ? 'text-cyan-300' : 'text-slate-100'}`}>{value}</strong></div>
);
const Reference = ({ label, pass }: { label: string; pass: boolean }) => (
  <div className={`p-2 rounded border ${pass ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300' : 'bg-amber-950/30 border-amber-800/40 text-amber-300'}`}>{label}</div>
);
