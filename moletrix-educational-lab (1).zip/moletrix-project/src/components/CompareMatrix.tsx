import React, { useState } from 'react';
import { CompareTarget, ProteinStructure } from '../types/protein';
import {
  BarChart3,
  Check,
  CheckCircle2,
  ChevronRight,
  GitCompare,
  Plus,
  Printer,
  Sparkles,
  Star,
  Trash2,
  TrendingDown,
  TrendingUp,
  Zap,
} from 'lucide-react';

interface CompareMatrixProps {
  targets: CompareTarget[];
  currentStructure: ProteinStructure;
  onAddCurrentToCompare: () => void;
  onRemoveTarget: (id: string) => void;
  onSetBaseline: (id: string) => void;
  onOpenPrintReport: () => void;
}

export const CompareMatrix: React.FC<CompareMatrixProps> = ({
  targets,
  currentStructure,
  onAddCurrentToCompare,
  onRemoveTarget,
  onSetBaseline,
  onOpenPrintReport,
}) => {
  const [isSynthesizingAi, setIsSynthesizingAi] = useState(false);
  const [aiComparison, setAiComparison] = useState<{
    recommendedCandidate: string;
    rankingRationale: string;
    thermostabilityTradeoffs: string;
    developabilityVerdict: string;
    dossierRecommendations: string[];
  } | null>(null);

  const baseline = targets.find((t) => t.isBaseline) || targets[0];
  const isCurrentInMatrix = targets.some((t) => t.id === currentStructure.id);

  // Build a descriptive summary from the displayed educational metrics
  const handleSynthesizeAi = async () => {
    setIsSynthesizingAi(true);
    try {
      // Descriptive educational comparison based only on the displayed structural metrics
        // Select target with highest combination of pLDDT, stability, and solubility
        let bestTarget = targets[0];
        let bestScore = -Infinity;
        targets.forEach((t) => {
          const score = t.properties.meanPlddt * 0.4 + t.properties.solubilityScore * 0.3 + (t.properties.isStable ? 20 : 0) - (t.properties.instabilityIndex * 0.2);
          if (score > bestScore) {
            bestScore = score;
            bestTarget = t;
          }
        });

        setAiComparison({
          recommendedCandidate: bestTarget.name,
          rankingRationale: `${bestTarget.name} demonstrates the superior composite developability profile with a mean pLDDT of ${bestTarget.properties.meanPlddt}%, solubility score of ${bestTarget.properties.solubilityScore}%, and favorable folding free energy (${bestTarget.properties.deltaG} kcal/mol).`,
          thermostabilityTradeoffs: `Melting temperatures range from ${Math.min(...targets.map((t) => t.properties.estimatedTm))}°C to ${Math.max(...targets.map((t) => t.properties.estimatedTm))}°C. Targets with higher aliphatic index show reduced conformational flexibility and lower aggregation propensity.`,
          developabilityVerdict: `This is a descriptive comparison of calculated educational structure metrics, not a recommendation for medical, therapeutic, or laboratory use.`,
          dossierRecommendations: [
            `Review the displayed confidence and stability metrics for ${bestTarget.name}.`,
            `Compare the predicted secondary-structure profiles across the selected examples.`,
            `Treat all computed values as estimates that require independent scientific validation.`,
          ],
        });
    } catch (e) {
      console.error(e);
    } finally {
      setIsSynthesizingAi(false);
    }
  };

  // Helper for rendering delta relative to baseline
  const renderDelta = (val: number, baseVal: number, unit: string = '', invertGood: boolean = false) => {
    if (val === baseVal) return null;
    const diff = Number((val - baseVal).toFixed(2));
    const isHigher = diff > 0;
    const isPositiveGood = invertGood ? !isHigher : isHigher;

    return (
      <span
        className={`inline-flex items-center text-[10px] font-mono px-1 py-0.2 rounded ml-1 ${
          isPositiveGood ? 'text-emerald-400 bg-emerald-950/60' : 'text-amber-400 bg-amber-950/60'
        }`}
      >
        {isHigher ? `+${diff}` : `${diff}`}{unit}
      </span>
    );
  };

  return (
    <div id="compare-matrix-section" className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-2xl space-y-5">
      {/* Compare Matrix Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-slate-100">Compare Matrix &amp; Multi-Protein Benchmark</h2>
            <span className="bg-cyan-950 text-cyan-300 text-xs px-2.5 py-0.5 rounded-full border border-cyan-800 font-mono">
              {targets.length} Targets
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Side-by-side educational structure metrics and relative baseline comparisons.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {!isCurrentInMatrix && (
            <button
              onClick={onAddCurrentToCompare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Current ({currentStructure.name})</span>
            </button>
          )}

          <button
            onClick={handleSynthesizeAi}
            disabled={isSynthesizingAi || targets.length < 2}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-200" />
            <span>{isSynthesizingAi ? 'Summarizing...' : 'Summarize Metrics'}</span>
          </button>

          <button
            onClick={onOpenPrintReport}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600 text-xs font-semibold shadow-md transition cursor-pointer"
            title="Print Final Dossier including this Compare Matrix"
          >
            <Printer className="w-4 h-4 text-cyan-400" />
            <span>Print Final Report</span>
          </button>
        </div>
      </div>

      {/* Target Selector / Baseline Bar */}
      <div className="flex flex-wrap items-center gap-2 bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 text-xs">
        <span className="text-slate-400 font-medium mr-1">Active Targets:</span>
        {targets.map((t) => {
          const isBase = t.id === baseline?.id;
          return (
            <div
              key={t.id}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition ${
                isBase
                  ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200 font-bold'
                  : 'bg-slate-900 border-slate-700/80 text-slate-300'
              }`}
            >
              <button
                onClick={() => onSetBaseline(t.id)}
                title={isBase ? 'Current baseline reference' : 'Click to set as reference baseline'}
                className="flex items-center gap-1 cursor-pointer hover:text-white"
              >
                {isBase && <Star className="w-3 h-3 text-cyan-400 fill-cyan-400" />}
                <span>{t.name}</span>
                {isBase && <span className="text-[10px] text-cyan-400 uppercase font-mono">(Baseline)</span>}
              </button>

              {targets.length > 2 && (
                <button
                  onClick={() => onRemoveTarget(t.id)}
                  title="Remove target from matrix"
                  className="text-slate-500 hover:text-red-400 ml-1 cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Side-by-Side Compare Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-950/90 text-slate-300 border-b border-slate-800">
              <th className="py-3 px-4 font-semibold text-slate-400 uppercase tracking-wider w-48">
                Biophysical Dimension
              </th>
              {targets.map((t) => {
                const isBase = t.id === baseline?.id;
                return (
                  <th key={t.id} className="py-3 px-4 font-bold text-slate-100 min-w-[200px]">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5">
                          <span>{t.name}</span>
                          {isBase && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-900/60 text-cyan-300 font-mono border border-cyan-700">
                              REF
                            </span>
                          )}
                        </div>
                        {t.badge && <div className="text-[10px] text-slate-400 font-normal">{t.badge}</div>}
                      </div>
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-300 font-mono">
            {/* Sequence Length */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Sequence Length</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 text-slate-200">
                  <span>{t.properties.sequenceLength} AA</span>
                  {renderDelta(t.properties.sequenceLength, baseline.properties.sequenceLength, ' AA')}
                </td>
              ))}
            </tr>

            {/* Molecular Weight */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Molecular Weight (kDa)</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 text-slate-200">
                  <span>{t.properties.molecularWeightKDa} kDa</span>
                  {renderDelta(t.properties.molecularWeightKDa, baseline.properties.molecularWeightKDa, ' kDa')}
                </td>
              ))}
            </tr>

            {/* Structural Confidence (Mean pLDDT) */}
            <tr className="hover:bg-slate-800/30 transition bg-slate-950/30">
              <td className="py-2.5 px-4 font-sans font-semibold text-cyan-300">Mean pLDDT Score (%)</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 font-bold text-cyan-200">
                  <span>{t.properties.meanPlddt}%</span>
                  {renderDelta(t.properties.meanPlddt, baseline.properties.meanPlddt, '%')}
                </td>
              ))}
            </tr>

            {/* Alpha Helix % */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Alpha Helix Content</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 text-purple-300">
                  <span>{t.properties.helixPercent}%</span>
                  {renderDelta(t.properties.helixPercent, baseline.properties.helixPercent, '%')}
                </td>
              ))}
            </tr>

            {/* Beta Sheet % */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Beta Sheet Content</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 text-teal-300">
                  <span>{t.properties.sheetPercent}%</span>
                  {renderDelta(t.properties.sheetPercent, baseline.properties.sheetPercent, '%')}
                </td>
              ))}
            </tr>

            {/* Isoelectric Point (pI) */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Isoelectric Point (pI)</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 text-slate-200">
                  <span>{t.properties.isoelectricPoint}</span>
                  {renderDelta(t.properties.isoelectricPoint, baseline.properties.isoelectricPoint)}
                </td>
              ))}
            </tr>

            {/* Net Charge @ pH 7.4 */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Net Charge (pH 7.4)</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4">
                  <span className={t.properties.netChargeAtPh74 > 0 ? 'text-blue-400' : 'text-red-400'}>
                    {t.properties.netChargeAtPh74 > 0 ? `+${t.properties.netChargeAtPh74}` : t.properties.netChargeAtPh74} e
                  </span>
                  {renderDelta(t.properties.netChargeAtPh74, baseline.properties.netChargeAtPh74, ' e')}
                </td>
              ))}
            </tr>

            {/* Folding Free Energy Delta G */}
            <tr className="hover:bg-slate-800/30 transition bg-slate-950/30">
              <td className="py-2.5 px-4 font-sans font-semibold text-emerald-300">Folding Free Energy (ΔG)</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 font-bold text-emerald-400">
                  <span>{t.properties.deltaG} kcal/mol</span>
                  {renderDelta(t.properties.deltaG, baseline.properties.deltaG, '', true)}
                </td>
              ))}
            </tr>

            {/* Melting Temperature Tm */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Est. Melting Temp (Tₘ)</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 text-amber-300 font-semibold">
                  <span>{t.properties.estimatedTm}°C</span>
                  {renderDelta(t.properties.estimatedTm, baseline.properties.estimatedTm, '°C')}
                </td>
              ))}
            </tr>

            {/* Total SASA */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Total SASA (Å²)</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 text-slate-200">
                  <span>{t.properties.totalSasa.toLocaleString()}</span>
                  {renderDelta(t.properties.totalSasa, baseline.properties.totalSasa, ' Å²')}
                </td>
              ))}
            </tr>

            {/* GRAVY Hydropathicity */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">GRAVY Index</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 text-slate-200">
                  <span>{t.properties.gravy}</span>
                  {renderDelta(t.properties.gravy, baseline.properties.gravy, '', true)}
                </td>
              ))}
            </tr>

            {/* Solubility Score */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Solubility Score</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 font-bold text-cyan-300">
                  <span>{t.properties.solubilityScore}%</span>
                  {renderDelta(t.properties.solubilityScore, baseline.properties.solubilityScore, '%')}
                </td>
              ))}
            </tr>

            {/* Instability Index */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Instability Index</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4">
                  <span className="text-slate-200 mr-1.5">{t.properties.instabilityIndex}</span>
                  <span className={`text-[9px] px-1.5 py-0.2 rounded font-sans uppercase font-bold ${
                    t.properties.isStable ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800'
                  }`}>
                    {t.properties.isStable ? 'Stable' : 'Unstable'}
                  </span>
                </td>
              ))}
            </tr>

            {/* Aggregation Risk */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Aggregation Risk</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 font-sans font-semibold">
                  <span className={t.properties.aggregationRisk === 'Low' ? 'text-emerald-400' : 'text-amber-400'}>
                    {t.properties.aggregationRisk}
                  </span>
                </td>
              ))}
            </tr>

            {/* Primary Active Site */}
            <tr className="hover:bg-slate-800/30 transition">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-400">Key Active Site</td>
              {targets.map((t) => (
                <td key={t.id} className="py-2.5 px-4 font-sans text-xs text-slate-300">
                  {t.keyActiveSite || 'Catalytic Surface'}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>

      {/* Educational metric summary */}
      {aiComparison && (
        <div className="bg-purple-950/30 border border-purple-800/60 rounded-xl p-4 space-y-3 text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="font-bold text-slate-100 text-sm">
              Highest composite metric score (educational): <strong className="text-purple-300">{aiComparison.recommendedCandidate}</strong>
            </span>
          </div>

          <p className="text-slate-300 leading-relaxed">{aiComparison.rankingRationale}</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="font-semibold text-amber-300 block pb-1">Stability metrics:</span>
              <p className="text-slate-300 leading-relaxed text-[11px]">{aiComparison.thermostabilityTradeoffs}</p>
            </div>
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <span className="font-semibold text-emerald-300 block pb-1">Metric context:</span>
              <p className="text-slate-300 leading-relaxed text-[11px]">{aiComparison.developabilityVerdict}</p>
            </div>
          </div>

          <div className="pt-1">
            <span className="font-semibold text-slate-300 block pb-1.5">Further learning:</span>
            <ul className="space-y-1">
              {aiComparison.dossierRecommendations.map((rec, i) => (
                <li key={i} className="flex items-center gap-2 text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
