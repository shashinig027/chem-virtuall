import React from 'react';
import { PREDEFINED_PROTEINS } from '../data/sampleProteins';
import { SAMPLE_MOLECULES, SmallMolecule } from '../data/sampleMolecules';
import { ProteinStructure } from '../types/protein';
import { Atom, ChevronDown, Dna, FlaskConical, GitCompare, Printer, Sparkles } from 'lucide-react';

interface NavbarProps {
  mode: 'proteins' | 'molecules';
  onSetMode: (mode: 'proteins' | 'molecules') => void;
  currentStructure: ProteinStructure;
  currentMolecule: SmallMolecule;
  onSelectProtein: (id: string) => void;
  onSelectMolecule: (id: string) => void;
  onOpenPredictModal: () => void;
  onOpenPrintReport: () => void;
  onScrollToCompare: () => void;
  compareCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  mode,
  onSetMode,
  currentStructure,
  currentMolecule,
  onSelectProtein,
  onSelectMolecule,
  onOpenPredictModal,
  onOpenPrintReport,
  onScrollToCompare,
  compareCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 shadow-lg print:hidden">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Logo & Brand */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-500 p-0.5 shadow-cyan-500/20 shadow-lg flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Atom className="w-5 h-5 text-cyan-400 animate-spin-slow" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-black tracking-wider text-slate-100">MOLETRIX</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                v4.8
              </span>
            </div>
            <p className="text-[11px] text-slate-400 -mt-0.5">Molecular Intelligence &amp; Virtual Chemistry</p>
          </div>
        </div>

        {/* Center Mode Switcher (Proteins vs Small Molecules) */}
        <div className="flex items-center gap-2">
          <div className="bg-slate-900 p-1 rounded-xl border border-slate-800 flex items-center gap-1 text-xs font-semibold">
            <button
              onClick={() => onSetMode('proteins')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                mode === 'proteins'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Dna className="w-3.5 h-3.5" />
              <span>Proteins</span>
            </button>
            <button
              onClick={() => onSetMode('molecules')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
                mode === 'molecules'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FlaskConical className="w-3.5 h-3.5" />
              <span>Small Molecules</span>
            </button>
          </div>

          {/* Target Selector */}
          <div className="relative">
            {mode === 'proteins' ? (
              <select
                value={currentStructure.id}
                onChange={(e) => onSelectProtein(e.target.value)}
                className="appearance-none bg-slate-900 border border-slate-700 hover:border-slate-600 text-slate-200 text-xs font-medium rounded-xl pl-3 pr-8 py-2 focus:outline-none focus:border-cyan-500 cursor-pointer shadow-sm"
              >
                {PREDEFINED_PROTEINS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.sequence.length} AA)
                  </option>
                ))}
                {!PREDEFINED_PROTEINS.some((p) => p.id === currentStructure.id) && (
                  <option value={currentStructure.id}>{currentStructure.name} (Custom)</option>
                )}
              </select>
            ) : (
              <select
                value={currentMolecule.id}
                onChange={(e) => onSelectMolecule(e.target.value)}
                className="appearance-none bg-slate-900 border border-slate-700 hover:border-slate-600 text-slate-200 text-xs font-medium rounded-xl pl-3 pr-8 py-2 focus:outline-none focus:border-cyan-500 cursor-pointer shadow-sm"
              >
                {SAMPLE_MOLECULES.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({m.formula})
                  </option>
                ))}
              </select>
            )}
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-3 pointer-events-none" />
          </div>

          {/* Predict Action */}
          <button
            onClick={onOpenPredictModal}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-md shadow-cyan-900/30 transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
            <span>Predict Protein</span>
          </button>
        </div>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onScrollToCompare}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 text-xs font-medium transition cursor-pointer"
          >
            <GitCompare className="w-4 h-4 text-cyan-400" />
            <span>Compare Matrix</span>
            <span className="w-4 h-4 rounded-full bg-cyan-900 text-cyan-300 text-[10px] flex items-center justify-center font-mono">
              {compareCount}
            </span>
          </button>

          <button
            onClick={onOpenPrintReport}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-800/60 hover:border-cyan-500 text-xs font-semibold shadow-md transition cursor-pointer"
            title="Print Final Research Report with Compare Matrix"
          >
            <Printer className="w-4 h-4 text-cyan-400" />
            <span>Print Report</span>
          </button>
        </div>
      </div>
    </header>
  );
};
