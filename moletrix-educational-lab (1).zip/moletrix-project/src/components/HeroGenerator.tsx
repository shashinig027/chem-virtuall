import React, { useState } from 'react';
import { SAMPLE_MOLECULES, SmallMolecule } from '../data/sampleMolecules';
import { PREDEFINED_PROTEINS } from '../data/sampleProteins';
import { ProteinStructure } from '../types/protein';
import {
  Atom,
  ChevronDown,
  Dna,
  Droplet,
  FileText,
  Flame,
  FlaskConical,
  Leaf,
  Search,
  Sliders,
  Sparkles,
  TestTube2,
  User,
  Zap,
} from 'lucide-react';

export type FilterCategory =
  | 'all'
  | 'smiles'
  | 'acids'
  | 'bases'
  | 'alcohols'
  | 'ketones'
  | 'aldehydes'
  | 'pharmaceuticals'
  | 'proteins';

interface HeroGeneratorProps {
  chemistName: string;
  onChangeChemistName: (name: string) => void;
  onOpenReport: () => void;
  activeFilter: FilterCategory;
  onSelectFilter: (filter: FilterCategory) => void;
  onGenerateQuery: (query: string) => Promise<void>;
  isLoading: boolean;
  activeMolecule: SmallMolecule | null;
  activeProtein: ProteinStructure | null;
  onSelectSessionMolecule: (id: string) => void;
  sessionMolecules: SmallMolecule[];
  isProteinActive: boolean;
}

export const HeroGenerator: React.FC<HeroGeneratorProps> = ({
  chemistName,
  onChangeChemistName,
  onOpenReport,
  activeFilter,
  onSelectFilter,
  onGenerateQuery,
  isLoading,
  activeMolecule,
  activeProtein,
  onSelectSessionMolecule,
  sessionMolecules,
  isProteinActive,
}) => {
  const [inputVal, setInputVal] = useState('cco');
  const [isEditingChemist, setIsEditingChemist] = useState(false);
  const [tempChemist, setTempChemist] = useState(chemistName);
  const [showAtmosphere, setShowAtmosphere] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    onGenerateQuery(inputVal.trim());
  };

  const handleSaveChemist = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempChemist.trim()) {
      onChangeChemistName(tempChemist.trim());
    }
    setIsEditingChemist(false);
  };

  const smilesPresets = [
    { label: 'Aspirin (SMILES)', query: 'CC(=O)Oc1ccccc1C(=O)O' },
    { label: 'Acetic Acid (SMILES)', query: 'CC(=O)O' },
    { label: 'Pyridine (SMILES)', query: 'c1ccncc1' },
    { label: 'Ethanol (SMILES)', query: 'CCO' },
    { label: 'Acetone (SMILES)', query: 'CC(=O)C' },
    { label: 'Benzaldehyde (SMILES)', query: 'c1ccccc1C=O' },
    { label: 'Paracetamol (SMILES)', query: 'CC(=O)Nc1ccc(O)cc1' },
    { label: 'Citric Acid (SMILES)', query: 'C(C(=O)O)C(CC(=O)O)(C(=O)O)O' },
    { label: 'Insulin (Protein)', query: 'Human Insulin' },
    { label: 'GFP (Protein)', query: 'Green Fluorescent Protein' },
    { label: 'Ubiquitin (Protein)', query: 'Ubiquitin' },
    { label: 'Spike RBD (Protein)', query: 'SARS-CoV-2 Spike RBD' },
  ];

  return (
    <div className="w-full space-y-6">
      {/* Top Header matching Screenshot */}
      <header className="flex flex-wrap items-center justify-between gap-4 py-2 border-b border-cyan-950/60">
        {/* Left Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-400/50 flex items-center justify-center shadow-lg shadow-cyan-950/40">
            <Atom className="w-6 h-6 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black tracking-wider text-white">MOLETRIX</span>
              <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-400 border border-cyan-500/60 font-bold tracking-wider">
                VIRTUAL CHEM LAB
              </span>
            </div>
            <p className="text-[11px] text-slate-400 tracking-wide">
              Molecular Intelligence • 3D Stereochemistry • Full Final Reports
            </p>
          </div>
        </div>

        {/* Right Action Bar */}
        <div className="flex items-center gap-2.5">
          {/* Chemist Pill */}
          <div className="relative">
            {isEditingChemist ? (
              <form onSubmit={handleSaveChemist} className="flex items-center gap-1">
                <input
                  type="text"
                  value={tempChemist}
                  onChange={(e) => setTempChemist(e.target.value)}
                  className="bg-slate-900 border border-cyan-500 text-xs px-2.5 py-1 rounded-lg text-white focus:outline-none"
                  autoFocus
                />
                <button type="submit" className="text-[11px] bg-cyan-600 px-2 py-1 rounded text-white font-bold">
                  Save
                </button>
              </form>
            ) : (
              <button
                onClick={() => setIsEditingChemist(true)}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 text-xs font-mono text-slate-300 hover:text-white transition cursor-pointer"
                title="Click to rename Lead Chemist"
              >
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span>Chemist: <strong className="text-white">{chemistName}</strong> ✎</span>
              </button>
            )}
          </div>

          {/* Overall Final Report Button */}
          <button
            onClick={onOpenReport}
            className="flex items-center gap-2 px-4 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/60 hover:border-cyan-400 text-cyan-300 text-xs font-mono font-bold shadow-md shadow-cyan-950/40 transition cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-cyan-400" />
            <span>Overall Final Report</span>
          </button>

          {/* Atmosphere Toggle */}
          <button
            onClick={() => setShowAtmosphere(!showAtmosphere)}
            title="Atmosphere & Background Settings"
            className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-300 transition cursor-pointer"
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Hero Center Title Section */}
      <div className="text-center space-y-3 pt-4">
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
          Explore{' '}
          <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-sky-400 bg-clip-text text-transparent">
            Molecules & Proteins
          </span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mx-auto leading-relaxed">
          Explore curated educational compounds and protein structures using names, formulas, or SMILES notation.
        </p>
        <p className="text-xs text-slate-400 max-w-xl mx-auto">
          Explore interactive 3D structures, molecular properties, spectroscopy, and printable learning reports.
        </p>

        {/* Lead Chemist Pill */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/80 text-[11px] text-slate-300 font-mono shadow-md">
          <User className="w-3.5 h-3.5 text-cyan-400" />
          <span>Lead Chemist: <strong className="text-white">{chemistName}</strong></span>
          <button
            onClick={() => setIsEditingChemist(true)}
            className="text-cyan-400 underline hover:text-cyan-200 cursor-pointer ml-1"
          >
            Change Name
          </button>
          <span className="text-slate-600">•</span>
          <span className="text-slate-400">Embedded directly into verified lab dossiers &amp; downloaded PDF files</span>
        </div>
      </div>

      {/* Filter Category Pills Bar */}
      <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-xs font-medium">
        {/* All Compounds */}
        <button
          onClick={() => onSelectFilter('all')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition cursor-pointer ${
            activeFilter === 'all'
              ? 'bg-cyan-600 text-white font-bold border-cyan-400 shadow-md shadow-cyan-950/40'
              : 'bg-slate-900/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>All Compounds</span>
          <span className="text-[10px] text-slate-400 bg-slate-950/60 px-1.5 py-0.2 rounded">Universal</span>
        </button>

        {/* SMILES Code */}
        <button
          onClick={() => onSelectFilter('smiles')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition cursor-pointer ${
            activeFilter === 'smiles'
              ? 'bg-cyan-600 text-white font-bold border-cyan-400 shadow-md shadow-cyan-950/40'
              : 'bg-slate-900/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
          }`}
        >
          <Dna className="w-3.5 h-3.5 text-cyan-400" />
          <span>SMILES Code</span>
          <span className="text-[10px] text-cyan-200 bg-cyan-950/80 px-1.5 py-0.2 rounded font-mono">Line Notation</span>
        </button>

        {/* Acids */}
        <button
          onClick={() => onSelectFilter('acids')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition cursor-pointer ${
            activeFilter === 'acids'
              ? 'bg-red-700 text-white font-bold border-red-500 shadow-md'
              : 'bg-slate-900/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
          }`}
        >
          <TestTube2 className="w-3.5 h-3.5 text-red-400" />
          <span>Acids (-COOH)</span>
          <span className="text-[10px] text-slate-400 bg-slate-950/60 px-1.5 py-0.2 rounded font-mono">pKa / H⁺ Donor</span>
        </button>

        {/* Bases */}
        <button
          onClick={() => onSelectFilter('bases')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition cursor-pointer ${
            activeFilter === 'bases'
              ? 'bg-amber-700 text-white font-bold border-amber-500 shadow-md'
              : 'bg-slate-900/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>Bases (-N:)</span>
          <span className="text-[10px] text-slate-400 bg-slate-950/60 px-1.5 py-0.2 rounded font-mono">pKb / H⁺ Acceptor</span>
        </button>

        {/* Alcohols */}
        <button
          onClick={() => onSelectFilter('alcohols')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition cursor-pointer ${
            activeFilter === 'alcohols'
              ? 'bg-blue-600 text-white font-bold border-blue-400 shadow-md'
              : 'bg-slate-900/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
          }`}
        >
          <Droplet className="w-3.5 h-3.5 text-blue-400" />
          <span>Alcohols (-OH)</span>
          <span className="text-[10px] text-slate-400 bg-slate-950/60 px-1.5 py-0.2 rounded">Hydroxyl</span>
        </button>

        {/* Ketones */}
        <button
          onClick={() => onSelectFilter('ketones')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition cursor-pointer ${
            activeFilter === 'ketones'
              ? 'bg-orange-600 text-white font-bold border-orange-400 shadow-md'
              : 'bg-slate-900/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
          }`}
        >
          <Flame className="w-3.5 h-3.5 text-orange-400" />
          <span>Ketones (C=O)</span>
          <span className="text-[10px] text-slate-400 bg-slate-950/60 px-1.5 py-0.2 rounded">Carbonyl</span>
        </button>

        {/* Aldehydes */}
        <button
          onClick={() => onSelectFilter('aldehydes')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition cursor-pointer ${
            activeFilter === 'aldehydes'
              ? 'bg-emerald-600 text-white font-bold border-emerald-400 shadow-md'
              : 'bg-slate-900/80 text-slate-300 border-slate-700/80 hover:bg-slate-800'
          }`}
        >
          <Leaf className="w-3.5 h-3.5 text-emerald-400" />
          <span>Aldehydes (-CHO)</span>
          <span className="text-[10px] text-slate-400 bg-slate-950/60 px-1.5 py-0.2 rounded">Formyl</span>
        </button>

        {/* Proteins & Macromolecules (NEW!) */}
        <button
          onClick={() => onSelectFilter('proteins')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition cursor-pointer ${
            activeFilter === 'proteins'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold border-purple-400 shadow-md'
              : 'bg-slate-900/80 text-purple-300 border-purple-800/80 hover:bg-slate-800'
          }`}
        >
          <Dna className="w-3.5 h-3.5 text-purple-400" />
          <span>Proteins &amp; Macromolecules</span>
          <span className="text-[10px] text-purple-200 bg-purple-950/80 px-1.5 py-0.2 rounded">Structure &amp; Compare</span>
        </button>
      </div>

      {/* Main Search / Generator Form */}
      <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
        <div className="flex flex-wrap items-center bg-slate-950/90 border border-cyan-500/50 rounded-2xl p-1.5 shadow-2xl backdrop-blur-xl">
          <div className="flex-1 flex items-center gap-3 px-3 py-1 min-w-[240px]">
            <Search className="w-5 h-5 text-cyan-400 shrink-0" />
            <input
              type="text"
              placeholder="Search the library by name, formula, SMILES, or protein..."
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              className="w-full bg-transparent text-sm font-mono text-white placeholder-slate-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2 p-1">
            <button
              type="submit"
              disabled={isLoading || !inputVal.trim()}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-white text-xs font-black tracking-wider uppercase shadow-lg shadow-cyan-500/25 transition cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-white" />
              <span>{isLoading ? 'Loading...' : 'EXPLORE'}</span>
            </button>
          </div>
        </div>
      </form>

      {/* Quick SMILES & Target Chips */}
      <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1 text-xs font-mono">
        <span className="text-slate-400 flex items-center gap-1 text-[11px] mr-1">
          <Dna className="w-3 h-3 text-cyan-400" />
          <span>SMILES Code Presets:</span>
        </span>
        {smilesPresets.map((preset) => (
          <button
            key={preset.label}
            type="button"
            onClick={() => {
              setInputVal(preset.query);
              onGenerateQuery(preset.query);
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700/70 hover:border-cyan-500/60 text-slate-300 hover:text-cyan-200 transition text-[11px] cursor-pointer"
          >
            {preset.label}
          </button>
        ))}
      </div>

      {/* Active Compound / Target Summary Bar matching Screenshot */}
      <div className="max-w-5xl mx-auto rounded-2xl bg-slate-900/85 border border-cyan-500/30 p-4 shadow-xl backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
        {/* Left Side Info */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-500/50 flex items-center justify-center font-mono font-black text-cyan-300 text-sm shadow-md">
            {isProteinActive ? '1P' : activeMolecule?.id === 'ethanol' ? '9A' : '01'}
          </div>

          <div className="space-y-0.5">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                {isProteinActive ? activeProtein?.name : activeMolecule?.name}
              </h2>

              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                {isProteinActive ? `${activeProtein?.sequence.length} AA` : activeMolecule?.formula}
              </span>

              <span className="text-[11px] px-2 py-0.5 rounded-full bg-blue-950/80 text-blue-300 border border-blue-800 flex items-center gap-1">
                {isProteinActive ? <Dna className="w-3 h-3" /> : <Droplet className="w-3 h-3" />}
                <span>
                  {isProteinActive ? 'Macromolecular Protein' : activeMolecule?.category || 'Organic Compound'}
                </span>
              </span>

              <span className="text-xs text-slate-400 font-mono">
                MW: {isProteinActive ? `${activeProtein?.properties.molecularWeightKDa} kDa` : `${activeMolecule?.properties.molecularWeight} g/mol`}
              </span>
            </div>

            <p className="text-xs text-slate-400 italic">
              {isProteinActive ? activeProtein?.organism || 'Synthetic / Computational' : activeMolecule?.iupacName || activeMolecule?.name}
            </p>
          </div>
        </div>

        {/* Right Side Session Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">
            🕒 Session ({sessionMolecules.length}):
          </span>
          <div className="relative">
            <select
              value={activeMolecule?.id || ''}
              onChange={(e) => onSelectSessionMolecule(e.target.value)}
              className="appearance-none bg-slate-950 border border-slate-700 text-xs font-mono text-cyan-300 rounded-xl pl-3 pr-8 py-2 focus:outline-none focus:border-cyan-500 cursor-pointer shadow-sm"
            >
              {sessionMolecules.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} [{m.formula}]
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-3 pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
};
