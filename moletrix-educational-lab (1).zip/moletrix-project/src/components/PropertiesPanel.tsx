import React, { useState } from 'react';
import { ProteinStructure, Residue } from '../types/protein';
import { Activity, AlertTriangle, Atom, Compass, Droplet, Flame, Layers, ShieldCheck, Zap } from 'lucide-react';

interface PropertiesPanelProps {
  structure: ProteinStructure;
  selectedResidueIndex: number | null;
  onSelectResidue: (index: number | null) => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  structure,
  selectedResidueIndex,
  onSelectResidue,
}) => {
  const [activeTab, setActiveTab] = useState<'properties' | 'ramachandran' | 'pockets'>('properties');
  const props = structure.properties;

  // Selected residue detail if any
  const selectedRes = selectedResidueIndex
    ? structure.residues.find((r) => r.index === selectedResidueIndex)
    : null;

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl flex flex-col space-y-4">
      {/* Tab Navigation */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-400" />
          <h3 className="text-base font-bold text-slate-100">Biophysical & Structural Properties</h3>
        </div>

        <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('properties')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
              activeTab === 'properties' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Metrics
          </button>
          <button
            onClick={() => setActiveTab('ramachandran')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
              activeTab === 'ramachandran' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Ramachandran Plot
          </button>
          <button
            onClick={() => setActiveTab('pockets')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
              activeTab === 'pockets' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Binding Pockets ({structure.pockets?.length || 0})
          </button>
        </div>
      </div>

      {/* Selected Residue Highlight Card */}
      {selectedRes && (
        <div className="bg-cyan-950/40 border border-cyan-800/60 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
            <span className="font-bold text-cyan-200">
              Selected: #{selectedRes.index} {selectedRes.name} ({selectedRes.code3})
            </span>
            <span className="text-slate-400">| Conformation: <strong className="text-slate-200 uppercase">{selectedRes.secondaryStructure}</strong></span>
          </div>
          <div className="flex items-center gap-4 text-slate-300">
            <span>pLDDT: <strong className="text-cyan-300">{selectedRes.plddt}%</strong></span>
            <span>φ: <strong className="text-slate-200">{selectedRes.phi}°</strong></span>
            <span>ψ: <strong className="text-slate-200">{selectedRes.psi}°</strong></span>
            <span>SASA: <strong className="text-slate-200">{selectedRes.sasa} Å²</strong></span>
            <button
              onClick={() => onSelectResidue(null)}
              className="text-cyan-400 hover:text-cyan-200 underline cursor-pointer text-[11px]"
            >
              Clear
            </button>
          </div>
        </div>
      )}

      {/* TAB 1: Biophysical Metrics Grid */}
      {activeTab === 'properties' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {/* Molecular Weight */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Molecular Weight</span>
            <div className="text-lg font-bold text-slate-100 flex items-baseline gap-1">
              <span>{props.molecularWeightKDa}</span>
              <span className="text-xs text-slate-400 font-normal">kDa</span>
            </div>
            <span className="text-[10px] text-slate-500">{(props.molecularWeightKDa * 1000).toLocaleString()} Da</span>
          </div>

          {/* Isoelectric Point (pI) */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Isoelectric Point (pI)</span>
            <div className="text-lg font-bold text-cyan-300">
              {props.isoelectricPoint}
            </div>
            <span className="text-[10px] text-slate-500">
              {props.isoelectricPoint > 7.4 ? 'Basic (Net positive)' : 'Acidic (Net negative)'}
            </span>
          </div>

          {/* Net Charge at pH 7.4 */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Charge @ pH 7.4</span>
            <div className={`text-lg font-bold ${props.netChargeAtPh74 > 0 ? 'text-blue-400' : props.netChargeAtPh74 < 0 ? 'text-red-400' : 'text-slate-300'}`}>
              {props.netChargeAtPh74 > 0 ? `+${props.netChargeAtPh74}` : props.netChargeAtPh74} e
            </div>
            <span className="text-[10px] text-slate-500">Physiological state</span>
          </div>

          {/* Extinction Coefficient */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Extinction Coeff (ε₂₈₀)</span>
            <div className="text-lg font-bold text-slate-100 flex items-baseline gap-1">
              <span>{props.extinctionCoefficient.toLocaleString()}</span>
              <span className="text-[10px] text-slate-400">M⁻¹cm⁻¹</span>
            </div>
            <span className="text-[10px] text-slate-500">Gill & von Hippel method</span>
          </div>

          {/* Instability Index */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Instability Index</span>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-slate-100">{props.instabilityIndex}</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${props.isStable ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/60' : 'bg-red-900/60 text-red-300 border border-red-700/60'}`}>
                {props.isStable ? 'STABLE' : 'UNSTABLE'}
              </span>
            </div>
            <span className="text-[10px] text-slate-500">&lt;40 implies test-tube stability</span>
          </div>

          {/* Estimated Melting Temp Tm */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Flame className="w-3 h-3 text-amber-400" />
              <span>Est. Melting Temp (Tₘ)</span>
            </span>
            <div className="text-lg font-bold text-amber-300 flex items-baseline gap-1">
              <span>{props.estimatedTm}</span>
              <span className="text-xs text-slate-400">°C</span>
            </div>
            <span className="text-[10px] text-slate-500">Thermostability threshold</span>
          </div>

          {/* Folding Free Energy Delta G */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Folding Free Energy (ΔG)</span>
            <div className="text-lg font-bold text-emerald-400 flex items-baseline gap-1">
              <span>{props.deltaG}</span>
              <span className="text-xs text-slate-400">kcal/mol</span>
            </div>
            <span className="text-[10px] text-slate-500">Native fold thermodynamics</span>
          </div>

          {/* Total SASA */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Total SASA</span>
            <div className="text-lg font-bold text-slate-100 flex items-baseline gap-1">
              <span>{props.totalSasa.toLocaleString()}</span>
              <span className="text-xs text-slate-400">Å²</span>
            </div>
            <span className="text-[10px] text-slate-500">Solvent accessible surface</span>
          </div>

          {/* Solubility Score */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Droplet className="w-3 h-3 text-cyan-400" />
              <span>Solubility Score</span>
            </span>
            <div className="text-lg font-bold text-cyan-300">
              {props.solubilityScore}%
            </div>
            <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
              <div style={{ width: `${props.solubilityScore}%` }} className="bg-cyan-400 h-full"></div>
            </div>
          </div>

          {/* Aggregation Risk */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <AlertTriangle className="w-3 h-3 text-yellow-400" />
              <span>Aggregation Risk</span>
            </span>
            <div className={`text-lg font-bold ${props.aggregationRisk === 'Low' ? 'text-emerald-400' : props.aggregationRisk === 'Moderate' ? 'text-yellow-400' : 'text-red-400'}`}>
              {props.aggregationRisk}
            </div>
            <span className="text-[10px] text-slate-500">Based on GRAVY &amp; β-sheet ratio</span>
          </div>

          {/* GRAVY */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">GRAVY Index</span>
            <div className="text-lg font-bold text-slate-100">
              {props.gravy}
            </div>
            <span className="text-[10px] text-slate-500">{props.gravy < 0 ? 'Net Hydrophilic' : 'Net Hydrophobic'}</span>
          </div>

          {/* Aliphatic Index */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 space-y-1">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Aliphatic Index</span>
            <div className="text-lg font-bold text-slate-100">
              {props.aliphaticIndex}
            </div>
            <span className="text-[10px] text-slate-500">Relative Ala/Val/Ile/Leu volume</span>
          </div>
        </div>
      )}

      {/* TAB 2: Ramachandran Plot */}
      {activeTab === 'ramachandran' && (
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-950/70 border border-slate-800 p-4 rounded-xl">
            {/* 2D Canvas Ramachandran Scatter Plot */}
            <div className="relative w-64 h-64 bg-slate-900 border border-slate-700 rounded-xl overflow-hidden shadow-inner flex items-center justify-center">
              {/* Favored Region Overlays */}
              <div className="absolute top-4 left-4 w-24 h-24 bg-teal-500/15 border border-teal-500/30 rounded-lg pointer-events-none" title="Beta-Sheet Region">
                <span className="text-[9px] text-teal-300 p-1">β-Sheet</span>
              </div>
              <div className="absolute bottom-8 left-4 w-20 h-20 bg-purple-500/15 border border-purple-500/30 rounded-lg pointer-events-none" title="Right-handed Alpha-Helix Region">
                <span className="text-[9px] text-purple-300 p-1">α-Helix (R)</span>
              </div>
              <div className="absolute top-8 right-8 w-14 h-14 bg-indigo-500/15 border border-indigo-500/30 rounded-lg pointer-events-none" title="Left-handed Alpha-Helix Region">
                <span className="text-[9px] text-indigo-300 p-1">α-Helix (L)</span>
              </div>

              {/* Axis crosshairs */}
              <div className="absolute top-0 bottom-0 left-1/2 w-px bg-slate-700 pointer-events-none"></div>
              <div className="absolute left-0 right-0 top-1/2 h-px bg-slate-700 pointer-events-none"></div>

              {/* Residue Points */}
              <svg className="w-full h-full absolute inset-0" viewBox="-180 -180 360 360">
                {structure.residues.map((res) => {
                  const x = res.phi;
                  const y = -res.psi; // invert for SVG y-axis
                  const isSelected = selectedResidueIndex === res.index;
                  let fill = '#94a3b8';
                  if (res.secondaryStructure === 'helix') fill = '#a855f7';
                  if (res.secondaryStructure === 'sheet') fill = '#14b8a6';
                  return (
                    <circle
                      key={res.index}
                      cx={x}
                      cy={y}
                      r={isSelected ? 6 : 3}
                      fill={isSelected ? '#38bdf8' : fill}
                      stroke={isSelected ? '#ffffff' : '#0f172a'}
                      strokeWidth={isSelected ? 2 : 0.8}
                      className="cursor-pointer hover:scale-150 transition"
                      onClick={() => onSelectResidue(res.index)}
                    >
                      <title>{`#${res.index} ${res.code3}: φ=${res.phi}°, ψ=${res.psi}° (${res.ramachandranRegion})`}</title>
                    </circle>
                  );
                })}
              </svg>
            </div>

            {/* Ramachandran Statistics */}
            <div className="flex-1 space-y-3 text-xs">
              <div className="text-slate-300 leading-relaxed">
                The Ramachandran plot visualizes the dihedral angles <strong className="text-cyan-300">φ (phi)</strong> and <strong className="text-cyan-300">ψ (psi)</strong> of all amino acid residues, validating backbone steric clashes and secondary structure conformations.
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                    <span className="text-slate-200">Favored Regions:</span>
                  </div>
                  <span className="font-bold text-emerald-400">
                    {(
                      (structure.residues.filter((r) => r.ramachandranRegion === 'favored').length /
                        structure.residues.length) *
                      100
                    ).toFixed(1)}%
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
                    <span className="text-slate-200">Allowed Regions:</span>
                  </div>
                  <span className="font-bold text-yellow-400">
                    {(
                      (structure.residues.filter((r) => r.ramachandranRegion === 'allowed').length /
                        structure.residues.length) *
                      100
                    ).toFixed(1)}%
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500"></span>
                    <span className="text-slate-200">Outliers:</span>
                  </div>
                  <span className="font-bold text-red-400">
                    {(
                      (structure.residues.filter((r) => r.ramachandranRegion === 'outlier').length /
                        structure.residues.length) *
                      100
                    ).toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Active Binding Pockets */}
      {activeTab === 'pockets' && (
        <div className="space-y-3">
          {structure.pockets && structure.pockets.length > 0 ? (
            structure.pockets.map((pocket) => (
              <div
                key={pocket.id}
                className="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 space-y-2 hover:border-emerald-600/60 transition"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-emerald-400" />
                    <span className="font-bold text-slate-100 text-sm">{pocket.name}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-slate-400">Druggability: <strong className="text-emerald-300 font-bold">{Math.round(pocket.druggabilityScore * 100)}%</strong></span>
                    <span className="text-slate-400">Volume: <strong className="text-slate-200">{pocket.volume} Å³</strong></span>
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{pocket.description}</p>
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] text-slate-400 mr-1">Residues:</span>
                  {pocket.residues.map((resIdx) => {
                    const r = structure.residues.find((x) => x.index === resIdx);
                    return (
                      <button
                        key={resIdx}
                        onClick={() => onSelectResidue(resIdx)}
                        className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 text-[11px] font-mono hover:bg-emerald-900 transition cursor-pointer"
                        title="Click to locate residue in 3D structure"
                      >
                        #{resIdx} {r?.code3 || 'RES'}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-slate-400 text-xs">
              No active binding pockets predicted for this structure.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
