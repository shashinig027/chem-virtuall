import { computeBiophysicalProperties, predictSecondaryStructureSequence } from '../utils/bioMath';
import { generateProtein3DStructure } from '../utils/coordinateGenerator';
import { CompareTarget, ProteinStructure } from '../types/protein';

export interface PredefinedProteinMeta {
  id: string;
  name: string;
  uniprotId: string;
  organism: string;
  badge: string;
  sequence: string;
  description: string;
  therapeuticCategory: string;
  keyActiveSite: string;
  pockets: Array<{
    id: string;
    name: string;
    residues: number[];
    druggabilityScore: number;
    volume: number;
    description: string;
  }>;
  aiInsights: {
    foldingMechanism: string;
    functionalDomains: string[];
    therapeuticPotential: string;
    engineeringRecommendations: string[];
    confidenceAssessment: string;
  };
}

export const PREDEFINED_PROTEINS: PredefinedProteinMeta[] = [
  {
    id: 'insulin-human',
    name: 'Insulin (Human)',
    uniprotId: 'P01308',
    organism: 'Homo sapiens',
    badge: 'Endocrine Hormone',
    therapeuticCategory: 'Metabolic & Diabetes Care',
    keyActiveSite: 'Insulin Receptor Contact Cleft (Gly1, Phe24, Tyr26)',
    sequence: 'GIVEQCCTSICSLYQLENYCNFVNQHLCGSHLVEALYLVCGERGFFYTPKT',
    description: 'Vital peptide hormone synthesized in pancreatic beta cells. Plays a central role in regulating glucose homeostasis, lipid metabolism, and cellular protein synthesis.',
    pockets: [
      {
        id: 'ins-poc-1',
        name: 'Insulin Receptor (IR) Primary Binding Surface',
        residues: [1, 2, 19, 24, 25, 26, 44, 45],
        druggabilityScore: 0.94,
        volume: 520,
        description: 'Hydrophobic patch formed by Phe24 and Tyr26 that docks into the alpha-subunit fibronectin III domains of human Insulin Receptor.',
      },
      {
        id: 'ins-poc-2',
        name: 'Hexamer Coordination Pocket (His10)',
        residues: [10, 13, 17, 34],
        druggabilityScore: 0.76,
        volume: 380,
        description: 'Zinc-coordinating histidine cluster responsible for hexameric storage and sustained subcutaneous bioavailability.',
      },
    ],
    aiInsights: {
      foldingMechanism: 'Three invariant disulfide bridges (Cys6-Cys11 intra-A, Cys7-Cys31 inter A-B, Cys20-Cys43 inter A-B) drive spontaneous oxidative refolding into a compact two-chain core.',
      functionalDomains: ['A-Chain Helical Receptor Recognition (1-21)', 'B-Chain Core Structural Spine (22-51)', 'C-terminal Dimerization Flap (45-51)'],
      therapeuticPotential: 'Standard-of-care insulin analogs (Lispro, Glargine, Degludec) engineered for ultrafast prandial action or ultra-long basal pharmacokinetics.',
      engineeringRecommendations: [
        'Substitute Tyr16 to Trp to enhance thermal stability without disrupting IR binding.',
        'PEGylation or fatty acid conjugation at Lys49 to extend serum half-life via albumin hitchhiking.',
        'Introduce Pro28Lys inversion to prevent self-association for rapid subcutaneous absorption.',
      ],
      confidenceAssessment: 'AlphaFold-level structural confidence: Mean pLDDT > 92.5. Disulfide connectivity verified against RCSB PDB entry 1TRZ.',
    },
  },
  {
    id: 'gfp-jellyfish',
    name: 'Green Fluorescent Protein (GFP)',
    uniprotId: 'P42212',
    organism: 'Aequorea victoria',
    badge: 'Fluorophore Benchmark',
    therapeuticCategory: 'Diagnostic Imaging & Biosensors',
    keyActiveSite: 'Fluorophore Core (Ser65-Tyr66-Gly67)',
    sequence: 'MSKGEELFTGVVPILVELDGDVNGHKFSVSGEGEGDATYGKLTLKFICTTGKLPVPWPTLVTTFSYGVQCFSRYPDHMKQHDFFKSAMPEGYVQERTIFFKDDGNYKTRAEVKFEGDTLVNRIELKGIDFKEDGNILGHKLEYNYNSHNVYIMADKQKNGIKVNFKIRHNIEDGSVQLADHYQQNTPIGDGPVLLPDNHYLSTQSALSKDPNEKRDHMVLLEFVTAAGITHGMDELYK',
    description: 'Iconic 11-stranded beta-barrel containing an autocatalytically formed internal 4-(p-hydroxybenzylidene)imidazolidin-5-one fluorophore emitting green light (λmax = 509 nm).',
    pockets: [
      {
        id: 'gfp-poc-1',
        name: 'Internal Chromophore Cavity',
        residues: [64, 65, 66, 67, 68, 96, 145, 148, 203, 222],
        druggabilityScore: 0.89,
        volume: 780,
        description: 'Rigid hydrophobic interior shielded from molecular oxygen and solvent quenching, critical for high quantum yield.',
      },
    ],
    aiInsights: {
      foldingMechanism: 'Classic beta-can fold. Strands 1-11 wrap into an antiparallel cylinder capped by short loops, threading a central distorted alpha-helix hosting the chromophore triad.',
      functionalDomains: ['11-Stranded Beta-Can Architecture (12-228)', 'Central Chromophoric Helix (56-72)', 'N/C terminal stabilization caps'],
      therapeuticPotential: 'Widely used in cellular biomarker imaging, high-throughput drug screening, and optogenetic reporter assays.',
      engineeringRecommendations: [
        'E222G / S65T mutations to accelerate fluorophore maturation and increase extinction coefficient.',
        'Circular permutation (cpGFP) for constructing calcium-responsive GCaMP sensors.',
        'Superfolder GFP (sfGFP) mutations (S30R, Y39N, F64L) to prevent misfolding in reducing mammalian cytoplasm.',
      ],
      confidenceAssessment: 'Extremely high confidence: Mean pLDDT 93.8. Rigid beta-sheet cylinder with very low RMSD vs PDB 1EMA.',
    },
  },
  {
    id: 'ubiquitin-human',
    name: 'Ubiquitin (Human)',
    uniprotId: 'P0CG48',
    organism: 'Homo sapiens',
    badge: 'Proteasome Signal',
    therapeuticCategory: 'Targeted Protein Degradation (PROTAC)',
    keyActiveSite: 'Isopeptide Linker Tail (Gly75-Gly76)',
    sequence: 'MQIFVKTLTGKTITLEVEPSDTIENVKAKIQDKEGIPPDQQRLIFAGKQLEDGRTLSDYNIQKESTLHLVLRLRGG',
    description: 'Highly conserved 76-amino-acid regulatory protein covalently tagged onto substrates to dictate 26S proteasome degradation, endocytosis, or DNA repair signaling.',
    pockets: [
      {
        id: 'ubi-poc-1',
        name: 'Hydrophobic Patch (Ile44 Surface)',
        residues: [8, 44, 68, 70],
        druggabilityScore: 0.85,
        volume: 460,
        description: 'Universal recognition epitope engaging UBA domains, CUE motifs, and proteasomal ubiquitin receptors.',
      },
      {
        id: 'ubi-poc-2',
        name: 'Lys48 Polyubiquitin Conjugation Cleft',
        residues: [48, 51, 54, 73, 76],
        druggabilityScore: 0.91,
        volume: 510,
        description: 'Site of K48-linked polyubiquitin chain formation, the canonical canonical signal for proteasomal degradation.',
      },
    ],
    aiInsights: {
      foldingMechanism: 'Mixed alpha/beta roll consisting of a 5-stranded beta sheet packed against an amphipathic alpha helix. Exhibits two-state folding kinetics with exceptional thermodynamic stability.',
      functionalDomains: ['Central Alpha-Helix (23-34)', 'Antiparallel Beta-Cradle (1-17, 40-72)', 'Flexible C-terminal Gly-Gly tail (71-76)'],
      therapeuticPotential: 'Targeted Protein Degradation (PROTACs), molecular glues, and deubiquitinating enzyme (DUB) oncology inhibitors.',
      engineeringRecommendations: [
        'K48R or K63R site-directed mutations to dissect specific non-degradative signaling cascades.',
        'Stabilize the flexible C-terminal tail with terminal amidation to prevent nonspecific DUB cleavage.',
      ],
      confidenceAssessment: 'Mean pLDDT 94.6. Minimal conformational variance across crystallographic and NMR ensembles.',
    },
  },
  {
    id: 'spike-rbd',
    name: 'SARS-CoV-2 Spike RBD',
    uniprotId: 'P0DTC2',
    organism: 'SARS-CoV-2',
    badge: 'Viral Antigen Target',
    therapeuticCategory: 'Neutralizing Antibodies & Vaccines',
    keyActiveSite: 'Receptor Binding Motif (RBM) / ACE2 Contact Cleft',
    sequence: 'RVQPTESIVRFPNITNLCPFGEVFNATRFASVYAWNRKRISNCVADYSVLYNSASFSTFKCYGVSPTKLNDLCFTNVYADSFVIRGDEVRQIAPGQTGKIADYNYKLPDDFTGCVIAWNSNNLDSKVGGNYNYLYRLFRKSNLKPFERDISTEIYQAGSTPCNGVEGFNCYFPLQSYGFQPTNGVGYQPYRVVVLSFELLHAPATVCGPKKSTNLVKNKCVNF',
    description: 'Receptor Binding Domain of the viral Spike glycoprotein. Directly binds human Angiotensin-Converting Enzyme 2 (ACE2) to mediate host cell viral entry.',
    pockets: [
      {
        id: 'rbd-poc-1',
        name: 'ACE2 Interfacial Contact Patch',
        residues: [453, 455, 456, 486, 489, 493, 498, 501, 505],
        druggabilityScore: 0.96,
        volume: 890,
        description: 'Concave hydrophilic and aromatic ridge engaging ACE2 alpha-1 helix with sub-nanomolar affinity.',
      },
    ],
    aiInsights: {
      foldingMechanism: 'Twisted five-stranded antiparallel beta-sheet core stabilized by three disulfide pairs, with an extended flexible receptor-binding motif (RBM) ridge.',
      functionalDomains: ['Core Scaffold Domain (333-437, 507-527)', 'Receptor Binding Motif RBM (438-506)', 'Disulfide Stabilizers (Cys336-Cys361, Cys379-Cys432, Cys391-Cys525)'],
      therapeuticPotential: 'Primary antigen for mRNA vaccines and monoclonal neutralizing antibody cocktails (e.g. Sotrovimab, Bebtelovimab).',
      engineeringRecommendations: [
        'Introduce 2P (K986P/V987P) or 6P proline stabilization in full Spike to lock in pre-fusion conformation.',
        'Engineered disulfide bond between residues 383 and 518 to enhance recombinant yield and shelf-life.',
      ],
      confidenceAssessment: 'Core domain pLDDT > 90; dynamic RBM loop pLDDT ~ 78, reflecting high conformational plasticity.',
    },
  },
  {
    id: 'p53-core',
    name: 'Tumor Protein p53 (Core Domain)',
    uniprotId: 'P04637',
    organism: 'Homo sapiens',
    badge: 'Tumor Suppressor',
    therapeuticCategory: 'Oncology Therapeutics & Refolding Chaperones',
    keyActiveSite: 'DNA Major Groove Binding Helix (Arg273, Arg280, Arg282)',
    sequence: 'SSSVPSQKTYQGSYGFRLGFLHSGTAKSVTCTYSPALNKMFCQLAKTCPVQLWVDSTPPPGTRVRAMAIYKQSQHMTEVVRRCPHHERCSDSDGLAPPQHLIRVEGNLRVEYLDDRNTFRHSVVVPYEPPEVGSDCTTIHYNYMCNSSCMGGMNRRPILTIITLEDSSGNLLGRNSFEVRVCACPGRDRRTEEENFRKKGEPHHELP',
    description: 'Master tumor suppressor known as the "guardian of the genome". Coordinates cell cycle arrest, senescence, and apoptosis in response to genotoxic stress.',
    pockets: [
      {
        id: 'p53-poc-1',
        name: 'Zinc Finger Coordination Center (C176, H179, C238, C242)',
        residues: [34, 37, 96, 100],
        druggabilityScore: 0.92,
        volume: 640,
        description: 'Tetrahedral coordination of Zn2+ ion essential for structural scaffolding and preventing oncogenic thermal denaturation.',
      },
      {
        id: 'p53-poc-2',
        name: 'Y220C Oncogenic Druggable Cavity',
        residues: [78, 79, 80, 81, 140, 141],
        druggabilityScore: 0.95,
        volume: 720,
        description: 'Mutation-induced crevice created by Tyr220Cys, target of clinical small-molecule stabilizers (PC14586).',
      },
    ],
    aiInsights: {
      foldingMechanism: 'Immunoglobulin-like beta-sandwich architecture consisting of two antiparallel beta-sheets with loop-sheet-helix motifs coordinating zinc.',
      functionalDomains: ['Beta-Sandwich Core (94-292)', 'L1/L2 Loop Zinc Finger (163-195)', 'L3 Minor Groove Binding Loop (236-251)'],
      therapeuticPotential: 'Primary target in >50% of all human cancers; mutant p53 reactivation using small molecule folding chaperones.',
      engineeringRecommendations: [
        'Target Y220C mutation with synthetic carbazole derivatives to restore wild-type DNA-binding geometry.',
        'Stabilize loop L3 through engineered salt bridges (Thr284Lys) to rescue hot-spot contact mutants.',
      ],
      confidenceAssessment: 'Mean pLDDT 89.2. Well-ordered core; dynamic loop L1 exhibits expected flexibility.',
    },
  },
  {
    id: 'lysozyme-c',
    name: 'Lysozyme C',
    uniprotId: 'P00698',
    organism: 'Gallus gallus',
    badge: 'Enzyme Standard',
    therapeuticCategory: 'Antimicrobial & Biomanufacturing Benchmark',
    keyActiveSite: 'Catalytic Dyad (Glu35 & Asp52)',
    sequence: 'KVFGRCELAAAMKRHGLDNYRGYSLGNWVCAAKFESNFNTQATNRNTDGSTDYGILQINSRWWCNDGRTPGSRNLCNIPCSALLSSDITASVNCAKKIVSDGNGMNAWVAWRNRCKGTDVQAWIRGCRL',
    description: 'Model 129-residue glycoside hydrolase that cleaves the beta-(1,4)-glycosidic bonds between N-acetylmuramic acid and N-acetylglucosamine in bacterial peptidoglycan walls.',
    pockets: [
      {
        id: 'lys-poc-1',
        name: 'Peptidoglycan Substrate Cleft',
        residues: [35, 52, 59, 62, 63, 101, 107, 108],
        druggabilityScore: 0.93,
        volume: 810,
        description: 'Deep central active site cleft accommodating hexasaccharide chains with general acid catalysis driven by Glu35.',
      },
    ],
    aiInsights: {
      foldingMechanism: 'Biphasic folding into two structural domains (alpha-domain with four helices and beta-domain with a triple-stranded beta-sheet), sealed by four disulfide bonds.',
      functionalDomains: ['Alpha-Helical Domain (1-39, 89-129)', 'Beta-Sheet Catalytic Cleft (40-88)', 'Disulfide Network (Cys6-127, Cys30-115, Cys64-80, Cys76-94)'],
      therapeuticPotential: 'Natural antimicrobial defense agent, food preservative, and benchmark for amyloid fibril aggregation research.',
      engineeringRecommendations: [
        'Engineered disulfide bond between residues 21 and 124 to boost thermostability past 90°C.',
        'Mutation of Trp62 to improve catalytic turnover against Gram-negative bacterial walls.',
      ],
      confidenceAssessment: 'Mean pLDDT 95.1. Prototypical high-resolution crystallographic structure.',
    },
  },
];

// Pre-compute built-in protein structures
export const BUILTIN_PROTEIN_STRUCTURES: Record<string, ProteinStructure> = {};

for (const meta of PREDEFINED_PROTEINS) {
  const sec = predictSecondaryStructureSequence(meta.sequence);
  const props = computeBiophysicalProperties(meta.sequence, sec);
  const structure = generateProtein3DStructure(
    meta.id,
    meta.name,
    meta.sequence,
    sec,
    props,
    meta.description,
    meta.pockets
  );
  structure.organism = meta.organism;
  structure.uniprotId = meta.uniprotId;
  structure.aiInsights = meta.aiInsights;
  BUILTIN_PROTEIN_STRUCTURES[meta.id] = structure;
}

// Default initial compare targets
export const INITIAL_COMPARE_TARGETS: CompareTarget[] = PREDEFINED_PROTEINS.slice(0, 4).map((p, idx) => ({
  id: p.id,
  name: p.name,
  badge: p.badge,
  sequence: p.sequence,
  properties: BUILTIN_PROTEIN_STRUCTURES[p.id].properties,
  keyActiveSite: p.keyActiveSite,
  therapeuticCategory: p.therapeuticCategory,
  isBaseline: idx === 0,
}));
