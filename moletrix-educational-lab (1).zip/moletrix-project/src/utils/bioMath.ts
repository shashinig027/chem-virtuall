import { BiophysicalProperties, Residue, SecondaryStructureType } from '../types/protein';

// 20 Standard Amino Acids Dictionary
export interface AminoAcidInfo {
  code1: string;
  code3: string;
  name: string;
  mw: number; // g/mol (residue weight inside chain)
  hydrophobicity: number; // Kyte-Doolittle scale
  pKa?: number; // Side-chain pKa if ionizable
  chargeType: 'positive' | 'negative' | 'neutral';
  helixPropensity: number; // Chou-Fasman P_alpha * 100
  sheetPropensity: number; // Chou-Fasman P_beta * 100
}

export const AMINO_ACIDS: Record<string, AminoAcidInfo> = {
  A: { code1: 'A', code3: 'ALA', name: 'Alanine', mw: 71.08, hydrophobicity: 1.8, chargeType: 'neutral', helixPropensity: 142, sheetPropensity: 83 },
  R: { code1: 'R', code3: 'ARG', name: 'Arginine', mw: 156.20, hydrophobicity: -4.5, pKa: 12.48, chargeType: 'positive', helixPropensity: 98, sheetPropensity: 93 },
  N: { code1: 'N', code3: 'ASN', name: 'Asparagine', mw: 114.11, hydrophobicity: -3.5, chargeType: 'neutral', helixPropensity: 67, sheetPropensity: 89 },
  D: { code1: 'D', code3: 'ASP', name: 'Aspartic Acid', mw: 115.09, hydrophobicity: -3.5, pKa: 3.86, chargeType: 'negative', helixPropensity: 101, sheetPropensity: 54 },
  C: { code1: 'C', code3: 'CYS', name: 'Cysteine', mw: 103.14, hydrophobicity: 2.5, pKa: 8.33, chargeType: 'neutral', helixPropensity: 70, sheetPropensity: 119 },
  E: { code1: 'E', code3: 'GLU', name: 'Glutamic Acid', mw: 129.12, hydrophobicity: -3.5, pKa: 4.25, chargeType: 'negative', helixPropensity: 151, sheetPropensity: 37 },
  Q: { code1: 'Q', code3: 'GLN', name: 'Glutamine', mw: 128.14, hydrophobicity: -3.5, chargeType: 'neutral', helixPropensity: 111, sheetPropensity: 110 },
  G: { code1: 'G', code3: 'GLY', name: 'Glycine', mw: 57.06, hydrophobicity: -0.4, chargeType: 'neutral', helixPropensity: 57, sheetPropensity: 75 },
  H: { code1: 'H', code3: 'HIS', name: 'Histidine', mw: 137.15, hydrophobicity: -3.2, pKa: 6.00, chargeType: 'positive', helixPropensity: 100, sheetPropensity: 87 },
  I: { code1: 'I', code3: 'ILE', name: 'Isoleucine', mw: 113.17, hydrophobicity: 4.5, chargeType: 'neutral', helixPropensity: 108, sheetPropensity: 160 },
  L: { code1: 'L', code3: 'LEU', name: 'Leucine', mw: 113.17, hydrophobicity: 3.8, chargeType: 'neutral', helixPropensity: 121, sheetPropensity: 130 },
  K: { code1: 'K', code3: 'LYS', name: 'Lysine', mw: 128.18, hydrophobicity: -3.9, pKa: 10.53, chargeType: 'positive', helixPropensity: 116, sheetPropensity: 74 },
  M: { code1: 'M', code3: 'MET', name: 'Methionine', mw: 131.21, hydrophobicity: 1.9, chargeType: 'neutral', helixPropensity: 145, sheetPropensity: 105 },
  F: { code1: 'F', code3: 'PHE', name: 'Phenylalanine', mw: 147.19, hydrophobicity: 2.8, chargeType: 'neutral', helixPropensity: 113, sheetPropensity: 138 },
  P: { code1: 'P', code3: 'PRO', name: 'Proline', mw: 97.12, hydrophobicity: -1.6, chargeType: 'neutral', helixPropensity: 57, sheetPropensity: 55 },
  S: { code1: 'S', code3: 'SER', name: 'Serine', mw: 87.08, hydrophobicity: -0.8, chargeType: 'neutral', helixPropensity: 77, sheetPropensity: 75 },
  T: { code1: 'T', code3: 'THR', name: 'Threonine', mw: 101.11, hydrophobicity: -0.7, chargeType: 'neutral', helixPropensity: 83, sheetPropensity: 119 },
  W: { code1: 'W', code3: 'TRP', name: 'Tryptophan', mw: 186.23, hydrophobicity: -0.9, chargeType: 'neutral', helixPropensity: 108, sheetPropensity: 137 },
  Y: { code1: 'Y', code3: 'TYR', name: 'Tyrosine', mw: 163.19, hydrophobicity: -1.3, pKa: 10.07, chargeType: 'neutral', helixPropensity: 69, sheetPropensity: 147 },
  V: { code1: 'V', code3: 'VAL', name: 'Valine', mw: 99.14, hydrophobicity: 4.2, chargeType: 'neutral', helixPropensity: 106, sheetPropensity: 170 },
};

// Clean and sanitize amino acid sequence
export function sanitizeSequence(raw: string): string {
  // Remove FASTA header line if present
  let seq = raw.trim();
  if (seq.startsWith('>')) {
    const lines = seq.split('\n');
    lines.shift();
    seq = lines.join('');
  }
  return seq.toUpperCase().replace(/[^A-Z]/g, '');
}

// Compute charge at a given pH
export function computeNetChargeAtPh(sequence: string, pH: number): number {
  const pK_Nterm = 9.69;
  const pK_Cterm = 2.34;
  let charge = 1 / (1 + Math.pow(10, pH - pK_Nterm)) - 1 / (1 + Math.pow(10, pK_Cterm - pH));

  for (const aa of sequence) {
    if (aa === 'D') charge -= 1 / (1 + Math.pow(10, 3.86 - pH));
    else if (aa === 'E') charge -= 1 / (1 + Math.pow(10, 4.25 - pH));
    else if (aa === 'C') charge -= 1 / (1 + Math.pow(10, 8.33 - pH));
    else if (aa === 'Y') charge -= 1 / (1 + Math.pow(10, 10.07 - pH));
    else if (aa === 'H') charge += 1 / (1 + Math.pow(10, pH - 6.0));
    else if (aa === 'K') charge += 1 / (1 + Math.pow(10, pH - 10.53));
    else if (aa === 'R') charge += 1 / (1 + Math.pow(10, pH - 12.48));
  }
  return charge;
}

// Isoelectric point (pI) bisection calculation
export function calculateIsoelectricPoint(sequence: string): number {
  let low = 0.0;
  let high = 14.0;
  for (let iter = 0; iter < 25; iter++) {
    const mid = (low + high) / 2;
    const charge = computeNetChargeAtPh(sequence, mid);
    if (charge > 0) {
      low = mid;
    } else {
      high = mid;
    }
  }
  return Number(((low + high) / 2).toFixed(2));
}

// Molecular Weight (kDa) with terminal H2O (18.015 Da)
export function calculateMolecularWeight(sequence: string): number {
  let mw = 18.015; // Terminal H + OH
  for (const aa of sequence) {
    mw += AMINO_ACIDS[aa]?.mw ?? 110;
  }
  return Number((mw / 1000).toFixed(2));
}

// Grand Average of Hydropathicity (GRAVY)
export function calculateGravy(sequence: string): number {
  if (!sequence.length) return 0;
  let sum = 0;
  for (const aa of sequence) {
    sum += AMINO_ACIDS[aa]?.hydrophobicity ?? 0;
  }
  return Number((sum / sequence.length).toFixed(3));
}

// Extinction coefficient at 280 nm in M^-1 cm^-1
export function calculateExtinctionCoefficient(sequence: string): number {
  let trp = 0;
  let tyr = 0;
  let cys = 0;
  for (const aa of sequence) {
    if (aa === 'W') trp++;
    else if (aa === 'Y') tyr++;
    else if (aa === 'C') cys++;
  }
  // Standard equation: E = (nW * 5500) + (nY * 1490) + (nCys_pairs * 125)
  return trp * 5500 + tyr * 1490 + Math.floor(cys / 2) * 125;
}

// Aliphatic Index = X(Ala) + a * X(Val) + b * (X(Ile) + X(Leu))
// where a = 2.9, b = 3.9
export function calculateAliphaticIndex(sequence: string): number {
  if (!sequence.length) return 0;
  let ala = 0, val = 0, ile = 0, leu = 0;
  for (const aa of sequence) {
    if (aa === 'A') ala++;
    else if (aa === 'V') val++;
    else if (aa === 'I') ile++;
    else if (aa === 'L') leu++;
  }
  const L = sequence.length;
  const index = (100 / L) * (ala + 2.9 * val + 3.9 * (ile + leu));
  return Number(index.toFixed(1));
}

// Instability Index (Guruprasad method)
export function calculateInstabilityIndex(sequence: string): { index: number; isStable: boolean } {
  // Approximate instability index formula based on destabilizing dipeptides
  let score = 0;
  const destabilizingPairs = new Set(['WW', 'WP', 'PP', 'PE', 'EP', 'QD', 'DQ', 'PK', 'KP', 'RR', 'RH', 'HY']);
  for (let i = 0; i < sequence.length - 1; i++) {
    const pair = sequence.slice(i, i + 2);
    if (destabilizingPairs.has(pair)) {
      score += 4.5;
    } else {
      score += 0.8;
    }
  }
  const index = Number(((10 / Math.max(1, sequence.length)) * score + 28).toFixed(1));
  return {
    index,
    isStable: index < 40,
  };
}

// Predict Secondary Structure using Chou-Fasman propensity windowing
export function predictSecondaryStructureSequence(sequence: string): SecondaryStructureType[] {
  const result: SecondaryStructureType[] = new Array(sequence.length).fill('loop');
  const windowSize = 5;

  for (let i = 0; i < sequence.length; i++) {
    let alphaSum = 0;
    let betaSum = 0;
    let count = 0;

    for (let w = -Math.floor(windowSize / 2); w <= Math.floor(windowSize / 2); w++) {
      const idx = i + w;
      if (idx >= 0 && idx < sequence.length) {
        const aa = sequence[idx];
        const info = AMINO_ACIDS[aa] || AMINO_ACIDS.A;
        alphaSum += info.helixPropensity;
        betaSum += info.sheetPropensity;
        count++;
      }
    }

    const avgAlpha = alphaSum / count;
    const avgBeta = betaSum / count;

    // Proline and Glycine act as helix & sheet breakers
    const currentAA = sequence[i];
    if (currentAA === 'P' || currentAA === 'G') {
      result[i] = 'turn';
    } else if (avgAlpha > 115 && avgAlpha >= avgBeta) {
      result[i] = 'helix';
    } else if (avgBeta > 115) {
      result[i] = 'sheet';
    } else {
      result[i] = 'loop';
    }
  }

  // Smooth out solitary 1-residue helices or sheets (they require min 3-4 residues physically)
  for (let i = 1; i < result.length - 1; i++) {
    if (result[i] === 'helix' && result[i - 1] !== 'helix' && result[i + 1] !== 'helix') {
      result[i] = 'loop';
    }
    if (result[i] === 'sheet' && result[i - 1] !== 'sheet' && result[i + 1] !== 'sheet') {
      result[i] = 'loop';
    }
  }

  return result;
}

// Compute comprehensive biophysical properties
export function computeBiophysicalProperties(sequence: string, secStructs: SecondaryStructureType[]): BiophysicalProperties {
  const L = sequence.length;
  const mw = calculateMolecularWeight(sequence);
  const pI = calculateIsoelectricPoint(sequence);
  const netCharge = Number(computeNetChargeAtPh(sequence, 7.4).toFixed(2));
  const extCoeff = calculateExtinctionCoefficient(sequence);
  const { index: instability, isStable } = calculateInstabilityIndex(sequence);
  const aliphatic = calculateAliphaticIndex(sequence);
  const gravy = calculateGravy(sequence);

  let helixCount = 0;
  let sheetCount = 0;
  let loopCount = 0;

  for (const ss of secStructs) {
    if (ss === 'helix') helixCount++;
    else if (ss === 'sheet') sheetCount++;
    else loopCount++;
  }

  const helixPercent = Number(((helixCount / L) * 100).toFixed(1));
  const sheetPercent = Number(((sheetCount / L) * 100).toFixed(1));
  const loopPercent = Number(((loopCount / L) * 100).toFixed(1));

  // Solvent Accessible Surface Area (SASA) approximation: Miller empirical power law SASA ~ 6.3 * MW^0.73
  const totalSasa = Math.round(6.3 * Math.pow(mw * 1000, 0.73));

  // Melting temp Tm estimation: correlated with aliphatic index, secondary structure compactness, and GRAVY
  const estimatedTm = Number((48 + (aliphatic * 0.18) + (helixPercent * 0.12) + (isStable ? 4 : -3)).toFixed(1));

  // Folding Free Energy Delta G (kcal/mol): typically -5 to -15 kcal/mol for globular proteins
  const deltaG = Number((-3.5 - (helixPercent * 0.08) - (sheetPercent * 0.05) - (isStable ? 3.0 : 0.5)).toFixed(2));

  // Solubility score (0 to 100%) - favors lower hydrophobicity, moderate charge, and stability
  const chargeFactor = Math.min(Math.abs(netCharge) / (L * 0.15), 1.0);
  const gravyPenalty = Math.max(0, (gravy + 0.5) * 40);
  const solubilityScore = Math.max(10, Math.min(99, Math.round(85 + (chargeFactor * 15) - gravyPenalty - (instability > 40 ? 12 : 0))));

  // Aggregation risk classification
  let aggregationRisk: BiophysicalProperties['aggregationRisk'] = 'Low';
  if (gravy > 0.3 || (sheetPercent > 45 && gravy > 0)) aggregationRisk = 'High';
  else if (gravy > 0.0 || sheetPercent > 35) aggregationRisk = 'Elevated';
  else if (gravy > -0.3) aggregationRisk = 'Moderate';

  // Mean pLDDT confidence (AlphaFold baseline ~84-93 for well-structured residues)
  const meanPlddt = Number((86.5 + (helixPercent * 0.07) + (sheetPercent * 0.04) - (loopPercent * 0.06)).toFixed(1));

  return {
    sequenceLength: L,
    molecularWeightKDa: mw,
    isoelectricPoint: pI,
    netChargeAtPh74: netCharge,
    extinctionCoefficient: extCoeff,
    instabilityIndex: instability,
    isStable,
    aliphaticIndex: aliphatic,
    gravy,
    totalSasa,
    estimatedTm,
    deltaG,
    solubilityScore,
    aggregationRisk,
    helixPercent,
    sheetPercent,
    loopPercent,
    meanPlddt,
  };
}

// Generate Ramachandran phi/psi angles based on secondary structure classification
export function generateRamachandranAngles(ss: SecondaryStructureType, aa: string): { phi: number; psi: number; region: 'favored' | 'allowed' | 'outlier' } {
  let basePhi = -60;
  let basePsi = -45;

  if (ss === 'helix') {
    // Alpha helix region: phi ~ -57 to -65, psi ~ -40 to -50
    basePhi = -60 + (Math.sin(aa.charCodeAt(0)) * 6);
    basePsi = -47 + (Math.cos(aa.charCodeAt(0)) * 6);
  } else if (ss === 'sheet') {
    // Beta sheet region: phi ~ -120 to -140, psi ~ +120 to +145
    basePhi = -135 + (Math.sin(aa.charCodeAt(0)) * 10);
    basePsi = 135 + (Math.cos(aa.charCodeAt(0)) * 10);
  } else if (aa === 'G') {
    // Glycine has conformational flexibility across all quadrants
    basePhi = (aa.charCodeAt(0) % 2 === 0 ? 65 : -65);
    basePsi = (aa.charCodeAt(0) % 3 === 0 ? 30 : -45);
  } else {
    // Turn / Loop region
    basePhi = -75 + (Math.sin(aa.charCodeAt(0)) * 18);
    basePsi = -20 + (Math.cos(aa.charCodeAt(0)) * 25);
  }

  // Region determination
  let region: 'favored' | 'allowed' | 'outlier' = 'favored';
  if (Math.abs(basePhi) > 165 || Math.abs(basePsi) > 170) region = 'outlier';
  else if (ss === 'loop' && (basePhi > 0 && aa !== 'G')) region = 'allowed';

  return {
    phi: Number(basePhi.toFixed(1)),
    psi: Number(basePsi.toFixed(1)),
    region,
  };
}
