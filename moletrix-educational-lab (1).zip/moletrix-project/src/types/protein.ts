export type SecondaryStructureType = 'helix' | 'sheet' | 'loop' | 'turn';

export interface Residue {
  index: number; // 1-based
  code1: string; // e.g. 'A'
  code3: string; // e.g. 'ALA'
  name: string; // e.g. 'Alanine'
  secondaryStructure: SecondaryStructureType;
  plddt: number; // 0 - 100 confidence
  caCoord: [number, number, number]; // [x, y, z] in Angstroms
  nCoord?: [number, number, number];
  cCoord?: [number, number, number];
  oCoord?: [number, number, number];
  phi: number; // Ramachandran phi angle in degrees
  psi: number; // Ramachandran psi angle in degrees
  ramachandranRegion: 'favored' | 'allowed' | 'outlier';
  hydrophobicity: number; // Kyte-Doolittle scale (-4.5 to 4.5)
  charge: number; // at pH 7.4
  sasa: number; // solvent accessible surface area in A^2
  isBindingSite?: boolean;
  bindingRole?: string;
}

export interface DisulfideBond {
  residue1: number;
  residue2: number;
  distance: number;
}

export interface HydrogenBond {
  fromResidue: number;
  toResidue: number;
  distance: number;
}

export interface ActivePocket {
  id: string;
  name: string;
  residues: number[];
  druggabilityScore: number; // 0 to 1
  volume: number; // in A^3
  description: string;
}

export interface BiophysicalProperties {
  sequenceLength: number;
  molecularWeightKDa: number;
  isoelectricPoint: number;
  netChargeAtPh74: number;
  extinctionCoefficient: number; // M^-1 cm^-1 at 280nm
  instabilityIndex: number;
  isStable: boolean;
  aliphaticIndex: number;
  gravy: number; // Grand average of hydropathicity
  totalSasa: number; // A^2
  estimatedTm: number; // Celsius
  deltaG: number; // kcal/mol folding free energy
  solubilityScore: number; // 0 to 100%
  aggregationRisk: 'Low' | 'Moderate' | 'Elevated' | 'High';
  helixPercent: number;
  sheetPercent: number;
  loopPercent: number;
  meanPlddt: number;
}

export interface ProteinStructure {
  id: string;
  name: string;
  organism?: string;
  uniprotId?: string;
  sequence: string;
  description: string;
  residues: Residue[];
  disulfideBonds: DisulfideBond[];
  hydrogenBonds: HydrogenBond[];
  pockets: ActivePocket[];
  properties: BiophysicalProperties;
  aiInsights?: {
    foldingMechanism: string;
    functionalDomains: string[];
    therapeuticPotential: string;
    engineeringRecommendations: string[];
    confidenceAssessment: string;
  };
  pdbString?: string;
}

export interface CompareTarget {
  id: string;
  name: string;
  badge?: string;
  sequence: string;
  properties: BiophysicalProperties;
  keyActiveSite?: string;
  therapeuticCategory?: string;
  isBaseline?: boolean;
}
